$ErrorActionPreference = 'Stop'
$bridge = Join-Path $PSScriptRoot 'trading-system\outputs\mt5_python_bridge'
$stopScript = Join-Path $bridge 'stop_auto_trader.ps1'
& $stopScript
$configPath = Join-Path $bridge 'auto_config.json'
$config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
$config.live_enabled = $false
$json = $config | ConvertTo-Json -Depth 20
[System.IO.File]::WriteAllText($configPath, $json + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))
Write-Output 'Auto trader stopped and live trading disabled.'
