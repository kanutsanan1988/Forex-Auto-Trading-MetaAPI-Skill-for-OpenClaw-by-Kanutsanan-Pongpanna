$ErrorActionPreference = 'Stop'
$pluginRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$venvPython = Join-Path $pluginRoot 'trading-system\.venv\Scripts\python.exe'
$server = Join-Path $PSScriptRoot 'mt5_mcp_server.py'
if (Test-Path -LiteralPath $venvPython) {
    & $venvPython $server
    exit $LASTEXITCODE
}
$python = Get-Command python.exe -ErrorAction SilentlyContinue
if (-not $python) { throw 'Python is unavailable. Run INSTALL-WINDOWS.ps1 first.' }
& $python.Source $server
exit $LASTEXITCODE
