from __future__ import annotations

import json
import importlib.util
import os
import subprocess
import sys
from pathlib import Path
from typing import Any


PLUGIN_ROOT = Path(__file__).resolve().parents[1]
SYSTEM_ROOT = PLUGIN_ROOT / "trading-system"
BRIDGE = SYSTEM_ROOT / "outputs" / "mt5_python_bridge"
VENV_PYTHON = SYSTEM_ROOT / ".venv" / "Scripts" / "python.exe"
PYTHON = VENV_PYTHON if VENV_PYTHON.is_file() else Path(sys.executable)
DEPENDENCY_READY = importlib.util.find_spec("MetaTrader5") is not None

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


TOOLS = [
    {
        "name": "mt5_setup_status",
        "description": "Check installation files and whether the local MT5 bridge is ready. Read-only.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "mt5_probe",
        "description": "Read the connected MT5 terminal, masked account, symbol specification, tick, and recent bars. Sends no order.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "mt5_analyze",
        "description": "Run the active multi-strategy router on closed bars and return a read-only market analysis.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "mt5_dry_run",
        "description": "Run one guarded decision cycle without permitting order_send.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "mt5_backtest",
        "description": "Run a conservative closed-bar backtest against the connected terminal history. Sends no order.",
        "inputSchema": {
            "type": "object",
            "properties": {"bars": {"type": "integer", "minimum": 500, "maximum": 20000, "default": 6000}},
            "additionalProperties": False,
        },
    },
    {
        "name": "mt5_trader_status",
        "description": "Show whether live mode, kill switch, trader, and supervisor are active. Read-only.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "mt5_enable_live_mode",
        "description": "Enable live mode only after verifying the masked account and explicit risk acknowledgement. Does not start trading.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "account_last3": {"type": "string", "pattern": "^[0-9]{3}$"},
                "max_risk_pct": {"type": "number", "minimum": 0.01, "maximum": 5.0},
                "daily_loss_limit_pct": {"type": "number", "minimum": 0.1, "maximum": 10.0},
                "confirmation": {"type": "string", "description": "Must equal I UNDERSTAND LIVE TRADING CAN LOSE MONEY"}
            },
            "required": ["account_last3", "max_risk_pct", "daily_loss_limit_pct", "confirmation"],
            "additionalProperties": False
        },
    },
    {
        "name": "mt5_disable_live_mode",
        "description": "Stop the package's trader processes and turn live mode off.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "mt5_start_auto_trader",
        "description": "Start the guarded live auto trader only after the user explicitly enabled live mode and supplies the exact confirmation phrase.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "confirmation": {"type": "string", "description": "Must equal START LIVE TRADING"}
            },
            "required": ["confirmation"],
            "additionalProperties": False,
        },
    },
    {
        "name": "mt5_stop_auto_trader",
        "description": "Create the kill switch and stop only processes recorded by this trading package.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
]


def completed(command: list[str], timeout: int = 180) -> dict[str, Any]:
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["KANATSANAN_PYTHON_EXE"] = str(PYTHON)
    try:
        result = subprocess.run(
            command,
            cwd=str(BRIDGE),
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
        )
        return {
            "ok": result.returncode == 0,
            "exit_code": result.returncode,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"Command timed out after {timeout} seconds"}


def powershell(script: str) -> list[str]:
    return ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(BRIDGE / script)]


def write_live_mode(enabled: bool, *, max_risk_pct: float | None = None,
                    daily_loss_limit_pct: float | None = None) -> dict[str, Any]:
    config_path = BRIDGE / "auto_config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    config["live_enabled"] = enabled
    if max_risk_pct is not None:
        config["max_risk_pct"] = max_risk_pct
    if daily_loss_limit_pct is not None:
        config["daily_loss_limit_pct"] = daily_loss_limit_pct
    config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return config


def call_tool(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    if name == "mt5_setup_status":
        config = BRIDGE / "auto_config.json"
        return {
            "ok": BRIDGE.is_dir() and config.is_file(),
            "plugin_root": str(PLUGIN_ROOT),
            "python": str(PYTHON),
            "venv_installed": VENV_PYTHON.is_file(),
            "metatrader5_available": DEPENDENCY_READY,
            "config_present": config.is_file(),
            "next": "Run INSTALL-WINDOWS.ps1 if venv_installed is false.",
        }
    if not DEPENDENCY_READY:
        return {"ok": False, "error": "Trading dependencies are not installed. Run INSTALL-WINDOWS.ps1 first."}
    if name == "mt5_probe":
        return completed([str(PYTHON), str(BRIDGE / "mt5_probe.py")])
    if name == "mt5_analyze":
        return completed([str(PYTHON), str(BRIDGE / "market_analyzer.py")])
    if name == "mt5_dry_run":
        return completed([str(PYTHON), str(BRIDGE / "auto_trader.py"), "--once"])
    if name == "mt5_backtest":
        bars = max(500, min(20000, int(arguments.get("bars", 6000))))
        return completed([str(PYTHON), str(BRIDGE / "strategy_backtest.py"), "--bars", str(bars)], timeout=600)
    if name == "mt5_trader_status":
        return completed(powershell("status_auto_trader.ps1"))
    if name == "mt5_enable_live_mode":
        if arguments.get("confirmation") != "I UNDERSTAND LIVE TRADING CAN LOSE MONEY":
            return {"ok": False, "error": "Exact live-risk acknowledgement is required."}
        last3 = str(arguments.get("account_last3", ""))
        if len(last3) != 3 or not last3.isdigit():
            return {"ok": False, "error": "account_last3 must contain exactly three digits."}
        risk = float(arguments.get("max_risk_pct", 0.0))
        daily = float(arguments.get("daily_loss_limit_pct", 0.0))
        if not 0.01 <= risk <= 5.0 or not 0.1 <= daily <= 10.0:
            return {"ok": False, "error": "Risk limits are outside the package safety bounds."}
        probe_result = completed([str(PYTHON), str(BRIDGE / "mt5_probe.py")])
        if not probe_result.get("ok"):
            return probe_result
        try:
            probe = json.loads(probe_result["stdout"])
            masked = str(probe["account"]["login_masked"])
        except (KeyError, TypeError, json.JSONDecodeError) as exc:
            return {"ok": False, "error": f"Could not verify masked MT5 account: {exc}"}
        if not masked.endswith(last3):
            return {"ok": False, "error": "Account confirmation does not match the connected MT5 account."}
        config = write_live_mode(True, max_risk_pct=risk, daily_loss_limit_pct=daily)
        return {"ok": True, "live_enabled": True, "account": masked, "symbol": os.environ.get("KANATSANAN_MT5_SYMBOL", config["symbol"]), "max_risk_pct": risk, "daily_loss_limit_pct": daily, "started": False}
    if name == "mt5_disable_live_mode":
        stopped = completed(powershell("stop_auto_trader.ps1"))
        config = write_live_mode(False)
        return {"ok": True, "live_enabled": False, "stopped": stopped, "symbol": config["symbol"]}
    if name == "mt5_start_auto_trader":
        if arguments.get("confirmation") != "START LIVE TRADING":
            return {"ok": False, "error": "Exact confirmation START LIVE TRADING is required."}
        return completed(powershell("start_auto_trader.ps1"))
    if name == "mt5_stop_auto_trader":
        return completed(powershell("stop_auto_trader.ps1"))
    return {"ok": False, "error": f"Unknown tool: {name}"}


def response(request_id: Any, result: Any = None, error: Any = None) -> None:
    payload: dict[str, Any] = {"jsonrpc": "2.0", "id": request_id}
    if error is not None:
        payload["error"] = error
    else:
        payload["result"] = result
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def main() -> int:
    for raw in sys.stdin:
        try:
            message = json.loads(raw)
            method = message.get("method")
            request_id = message.get("id")
            if method == "initialize":
                requested = message.get("params", {}).get("protocolVersion", "2025-06-18")
                response(request_id, {
                    "protocolVersion": requested,
                    "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {"name": "kanatsanan-mt5-trading-suite", "version": "1.0.0"},
                    "instructions": "Read-only by default. Never start live trading without explicit current-turn user confirmation.",
                })
            elif method == "tools/list":
                response(request_id, {"tools": TOOLS})
            elif method == "tools/call":
                params = message.get("params", {})
                result = call_tool(params.get("name", ""), params.get("arguments") or {})
                response(request_id, {
                    "content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False, indent=2)}],
                    "isError": not bool(result.get("ok")),
                })
            elif request_id is not None:
                response(request_id, error={"code": -32601, "message": f"Method not found: {method}"})
        except Exception as exc:
            if "request_id" in locals() and request_id is not None:
                response(request_id, error={"code": -32603, "message": str(exc)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
