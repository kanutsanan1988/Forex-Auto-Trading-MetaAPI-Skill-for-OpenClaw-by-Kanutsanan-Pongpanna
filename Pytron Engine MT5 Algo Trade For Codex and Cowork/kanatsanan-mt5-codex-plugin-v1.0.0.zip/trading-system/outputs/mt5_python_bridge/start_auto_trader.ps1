$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'

$project = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..\..')).Path
$work = Join-Path $project 'work'
$stopFile = Join-Path $work 'AUTO_TRADER_STOP'
$pidFile = Join-Path $work 'auto_trader_supervisor.pid'
$configPath = Join-Path $PSScriptRoot 'auto_config.json'
$supervisor = Join-Path $PSScriptRoot 'auto_trader_supervisor.ps1'

if (Test-Path -LiteralPath $stopFile) {
    throw "Kill switch exists: $stopFile. Review it before removing and restarting."
}
$config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
if (-not $config.live_enabled) { throw 'live_enabled is false in auto_config.json' }
if (Test-Path -LiteralPath $pidFile) {
    $existingPid = [int](Get-Content -LiteralPath $pidFile -Raw)
    if (Get-Process -Id $existingPid -ErrorAction SilentlyContinue) {
        throw "Supervisor is already running with PID $existingPid"
    }
}

$hostExecutable = (Get-Process -Id $PID).Path
$arguments = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $supervisor + '"'))
$process = Start-Process -FilePath $hostExecutable -ArgumentList $arguments -WindowStyle Hidden -PassThru
Start-Sleep -Seconds 2
if ($process.HasExited) { throw "Supervisor failed to start; exit code $($process.ExitCode)" }
Write-Output "Auto trader supervisor started. PID=$($process.Id)"
