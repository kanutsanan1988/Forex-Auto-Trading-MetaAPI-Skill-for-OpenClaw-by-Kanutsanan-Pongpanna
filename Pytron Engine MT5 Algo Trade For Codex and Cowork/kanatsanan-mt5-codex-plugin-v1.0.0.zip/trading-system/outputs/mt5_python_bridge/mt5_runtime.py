from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Iterable

import MetaTrader5 as mt5


HERE = Path(__file__).resolve().parent
CONFIG_FILE = HERE / "auto_config.json"


def load_config() -> dict:
    config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    if os.environ.get("KANATSANAN_MT5_SYMBOL"):
        config["symbol"] = os.environ["KANATSANAN_MT5_SYMBOL"]
    if os.environ.get("KANATSANAN_MT5_TERMINAL"):
        config["terminal_path"] = os.environ["KANATSANAN_MT5_TERMINAL"]
    return config


def configured_terminal_path(config: dict | None = None) -> Path | None:
    config = config or load_config()
    raw = os.environ.get("KANATSANAN_MT5_TERMINAL") or config.get("terminal_path")
    if not raw:
        return None
    path = Path(os.path.expandvars(str(raw))).expanduser()
    return path if path.is_file() else None


def terminal_candidates() -> Iterable[Path]:
    seen: set[str] = set()
    explicit = configured_terminal_path()
    if explicit:
        seen.add(str(explicit).lower())
        yield explicit

    roots = [
        os.environ.get("ProgramFiles"),
        os.environ.get("ProgramW6432"),
        os.environ.get("LOCALAPPDATA"),
    ]
    fixed = [
        Path(root) / "MetaTrader 5" / "terminal64.exe"
        for root in roots if root
    ]
    for path in fixed:
        key = str(path).lower()
        if key not in seen and path.is_file():
            seen.add(key)
            yield path

    for root in roots:
        if not root:
            continue
        base = Path(root)
        if not base.is_dir():
            continue
        for path in base.glob("MetaTrader*/*terminal64.exe"):
            key = str(path).lower()
            if key not in seen and path.is_file():
                seen.add(key)
                yield path


def initialize_mt5(config: dict | None = None) -> bool:
    """Connect to the user's logged-in terminal without storing credentials."""
    explicit = configured_terminal_path(config)
    if explicit and mt5.initialize(path=str(explicit)):
        return True

    # MetaTrader5 can attach to the currently registered/running terminal.
    if mt5.initialize():
        return True

    for candidate in terminal_candidates():
        if explicit and candidate == explicit:
            continue
        if mt5.initialize(path=str(candidate)):
            return True
    return False


def discover_gold_symbols() -> list[str]:
    symbols = mt5.symbols_get() or ()
    candidates = []
    for symbol in symbols:
        name = str(symbol.name)
        upper = name.upper()
        if "XAU" in upper or "GOLD" in upper:
            candidates.append(name)

    priorities = ("XAUUSD", "GOLD")
    return sorted(
        set(candidates),
        key=lambda name: (
            0 if name.upper() in priorities else 1,
            0 if name.upper().startswith("XAUUSD") else 1,
            len(name),
            name.upper(),
        ),
    )


def masked_login(login: int) -> str:
    text = str(login)
    return "*" * max(0, len(text) - 3) + text[-3:]
