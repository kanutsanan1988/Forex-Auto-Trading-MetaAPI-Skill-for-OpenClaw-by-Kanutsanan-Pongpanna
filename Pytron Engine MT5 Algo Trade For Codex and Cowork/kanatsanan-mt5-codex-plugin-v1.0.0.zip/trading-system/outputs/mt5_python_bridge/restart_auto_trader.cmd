@echo off
setlocal
pushd "%~dp0"
echo Stopping MT5 auto trader...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop_auto_trader.ps1"
if errorlevel 1 goto :error
echo Clearing kill switch...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0clear_kill_switch.ps1"
if errorlevel 1 goto :error
echo Starting MT5 auto trader...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_auto_trader.ps1"
if errorlevel 1 goto :error
echo.
echo Auto trader restarted successfully.
pause
popd
exit /b 0
:error
echo.
echo Auto trader restart failed. Review the message above.
pause
popd
exit /b 1
