from __future__ import annotations

import argparse
import json
from pathlib import Path

import MetaTrader5 as mt5

from mt5_runtime import CONFIG_FILE, discover_gold_symbols, initialize_mt5, masked_login


def main() -> int:
    parser = argparse.ArgumentParser(description="Configure this copy for the local logged-in MT5 terminal")
    parser.add_argument("--terminal", help="Optional full path to terminal64.exe")
    parser.add_argument("--symbol", help="Broker symbol to trade, for example XAUUSD or XAUUSDm")
    args = parser.parse_args()

    config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    if args.terminal:
        terminal = Path(args.terminal).expanduser().resolve()
        if not terminal.is_file() or terminal.name.lower() != "terminal64.exe":
            raise SystemExit(f"Invalid MT5 terminal path: {terminal}")
        config["terminal_path"] = str(terminal)

    if not initialize_mt5(config):
        print(json.dumps({"ok": False, "error": mt5.last_error(), "next": "Open and log in to MT5, then run setup again."}, ensure_ascii=False))
        return 1

    try:
        account = mt5.account_info()
        terminal_info = mt5.terminal_info()
        if account is None or terminal_info is None:
            raise RuntimeError(f"MT5 account/terminal unavailable: {mt5.last_error()}")

        candidates = discover_gold_symbols()
        symbol = args.symbol or config.get("symbol")
        if not symbol or mt5.symbol_info(symbol) is None:
            symbol = candidates[0] if candidates else None
        if not symbol or mt5.symbol_info(symbol) is None:
            raise RuntimeError("No gold symbol found. Re-run with --symbol followed by the broker's gold symbol.")

        if not mt5.symbol_select(symbol, True):
            raise RuntimeError(f"Could not select {symbol}: {mt5.last_error()}")

        config["terminal_path"] = str(Path(terminal_info.path) / "terminal64.exe")
        config["symbol"] = symbol
        config["live_enabled"] = False
        CONFIG_FILE.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({
            "ok": True,
            "terminal": config["terminal_path"],
            "account": masked_login(account.login),
            "server": account.server,
            "symbol": symbol,
            "gold_symbol_candidates": candidates[:20],
            "live_enabled": False,
            "next": "Run test_connection.ps1. Live trading remains disabled.",
        }, ensure_ascii=False, indent=2))
        return 0
    finally:
        mt5.shutdown()


if __name__ == "__main__":
    raise SystemExit(main())
