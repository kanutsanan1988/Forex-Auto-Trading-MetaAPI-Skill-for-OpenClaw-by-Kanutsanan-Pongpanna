$ErrorActionPreference = 'Stop'
$systemRoot = Join-Path $PSScriptRoot 'trading-system'
$python = Join-Path $systemRoot '.venv\Scripts\python.exe'
$bridge = Join-Path $systemRoot 'outputs\mt5_python_bridge'
if (-not (Test-Path -LiteralPath $python)) { throw 'Run INSTALL-WINDOWS.ps1 first.' }
& $python (Join-Path $bridge 'mt5_probe.py')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $python (Join-Path $bridge 'market_analyzer.py')
exit $LASTEXITCODE
