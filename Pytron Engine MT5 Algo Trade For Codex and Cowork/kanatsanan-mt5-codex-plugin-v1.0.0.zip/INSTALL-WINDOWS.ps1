[CmdletBinding()]
param(
    [string]$TerminalPath,
    [string]$Symbol
)

$ErrorActionPreference = 'Stop'
$systemRoot = Join-Path $PSScriptRoot 'trading-system'
$bridge = Join-Path $systemRoot 'outputs\mt5_python_bridge'
$venvPython = Join-Path $systemRoot '.venv\Scripts\python.exe'

if ($env:OS -ne 'Windows_NT') {
    throw 'MetaTrader5 Python integration in this package requires Windows.'
}

if (-not (Test-Path -LiteralPath $venvPython)) {
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        & $launcher.Source -3 -m venv (Join-Path $systemRoot '.venv')
    } else {
        $python = Get-Command python.exe -ErrorAction SilentlyContinue
        if (-not $python) {
            throw 'Python 3 was not found. Install Python 3.11 or newer, then run this installer again.'
        }
        & $python.Source -m venv (Join-Path $systemRoot '.venv')
    }
}

& $venvPython -m pip install --disable-pip-version-check -r (Join-Path $bridge 'requirements.txt')

$configureArgs = @((Join-Path $bridge 'configure_installation.py'))
if ($TerminalPath) { $configureArgs += @('--terminal', $TerminalPath) }
if ($Symbol) { $configureArgs += @('--symbol', $Symbol) }
& $venvPython @configureArgs
if ($LASTEXITCODE -ne 0) { throw 'MT5 configuration failed. Open and log in to MT5, then retry.' }

& $venvPython (Join-Path $bridge 'mt5_probe.py')
if ($LASTEXITCODE -ne 0) { throw 'MT5 connection test failed.' }

Write-Output ''
Write-Output 'Installation complete. Live trading is OFF.'
Write-Output 'Run TEST-READ-ONLY.ps1 before considering live trading.'
