[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][ValidatePattern('^\d{3}$')][string]$AccountLast3,
    [Parameter(Mandatory = $true)][ValidateRange(0.01, 5.0)][double]$MaxRiskPct,
    [Parameter(Mandatory = $true)][ValidateRange(0.1, 10.0)][double]$DailyLossLimitPct,
    [Parameter(Mandatory = $true)][string]$Confirmation
)

$ErrorActionPreference = 'Stop'
if ($Confirmation -cne 'I UNDERSTAND LIVE TRADING CAN LOSE MONEY') {
    throw 'Confirmation text did not match exactly.'
}

$systemRoot = Join-Path $PSScriptRoot 'trading-system'
$python = Join-Path $systemRoot '.venv\Scripts\python.exe'
$bridge = Join-Path $systemRoot 'outputs\mt5_python_bridge'
$configPath = Join-Path $bridge 'auto_config.json'
if (-not (Test-Path -LiteralPath $python)) { throw 'Run INSTALL-WINDOWS.ps1 first.' }

$probeText = (& $python (Join-Path $bridge 'mt5_probe.py') | Out-String)
if ($LASTEXITCODE -ne 0) { throw 'MT5 connection test failed.' }
$probe = $probeText | ConvertFrom-Json
if (-not $probe.ok) { throw 'MT5 probe did not return a safe connected state.' }
$masked = [string]$probe.account.login_masked
if (-not $masked.EndsWith($AccountLast3)) { throw 'Account confirmation does not match the logged-in MT5 account.' }

$config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
$config.max_risk_pct = $MaxRiskPct
$config.daily_loss_limit_pct = $DailyLossLimitPct
$config.live_enabled = $true
$json = $config | ConvertTo-Json -Depth 20
[System.IO.File]::WriteAllText($configPath, $json + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))

Write-Output "Live trading enabled for account $masked on symbol $($config.symbol)."
Write-Output "Maximum risk per order: $MaxRiskPct%"
Write-Output "Daily loss limit: $DailyLossLimitPct%"
Write-Output 'No process was started. Ask Codex/Cowork to show status before starting.'
