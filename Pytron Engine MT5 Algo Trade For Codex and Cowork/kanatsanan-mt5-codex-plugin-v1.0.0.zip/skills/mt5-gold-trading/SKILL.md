---
name: mt5-gold-trading
description: Analyze, backtest, configure, monitor, start, or stop the packaged Kanatsanan MT5 gold trading system on a user's own Windows computer. Use for this package's MT5 connection, XAUUSD broker-symbol setup, guarded automation, strategy diagnostics, or trading status; do not use for unrelated trading systems.
---

# MT5 Gold Trading

Operate the packaged system through its `mt5_*` MCP tools when they are available. If the tools are unavailable, read [references/operations.md](references/operations.md) and help the user install the local package before attempting MT5 work.

## Core workflow

1. Call `mt5_setup_status`, then `mt5_probe`. Never request or store an MT5 password; the bridge attaches to the terminal already logged in on the user's computer.
2. Confirm the masked account, broker server, configured symbol, terminal connection, and whether live mode is enabled.
3. Prefer `mt5_analyze`, `mt5_dry_run`, and `mt5_backtest` for analysis. State that backtests and signals do not guarantee profit.
4. Use `mt5_trader_status` before and after any process-control action.

## Live-trading boundary

- Read-only analysis and backtests may run when requested without changing live settings.
- Never enable live mode, change risk limits, or start the trader merely because the user asks for analysis, setup, testing, status, or recommendations.
- Live mode may be enabled only by the user's direct use of `ENABLE-LIVE-TRADING.ps1` or an explicit current-turn request to call `mt5_enable_live_mode`. Both flows require the masked account's last three digits, explicit risk limits, and the exact risk acknowledgement. Do not bypass or rewrite that confirmation flow.
- Call `mt5_start_auto_trader` only after the user explicitly asks to start live trading in the current conversation, `mt5_trader_status` shows live mode enabled, and the connected account/symbol have been shown to the user. Pass the exact tool confirmation only at that point.
- `mt5_stop_auto_trader` may be used immediately when the user asks to stop or pause. Use `mt5_disable_live_mode` when the user asks to disable live mode as well. Verify stopped status afterward.
- If the account, server, symbol, or stored account binding changes unexpectedly, stop and ask the user to review it. Never delete state to force acceptance of a new account.

Preserve the strategy implementation and the user's explicit configuration. Explain observed state and errors; do not represent this system as financial advice or a guarantee.
