# Installation and operations

## Requirements

- Windows 10 or 11
- MetaTrader 5 installed, open, and logged in to the user's own account
- Internet access during first installation so `MetaTrader5` can be installed
- Algo Trading enabled only when the user deliberately intends to trade live

## Package scripts

Run these from the extracted plugin/package root:

- `INSTALL-WINDOWS.ps1`: creates the isolated environment, installs the MT5 Python package, discovers the terminal and broker gold symbol, and leaves live mode off.
- `TEST-READ-ONLY.ps1`: probes MT5 and runs closed-bar analysis without sending an order.
- `ENABLE-LIVE-TRADING.ps1`: requires the account's last three digits, explicit risk limits, and the exact risk acknowledgement. It does not start a process.
- `DISABLE-LIVE-TRADING.ps1`: sets the kill switch, stops recorded package processes, and disables live mode.

If automatic symbol discovery is wrong, rerun installation with `-Symbol <broker-symbol>`. Common names include `XAUUSD`, `XAUUSDm`, `XAUUSD.sml`, and `GOLD`.

Runtime state and audit files are created locally under `trading-system/work`. They are never part of the distributed archive.
