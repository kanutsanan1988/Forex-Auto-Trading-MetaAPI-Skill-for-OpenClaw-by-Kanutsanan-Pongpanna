#!/usr/bin/env node

/**
 * IRIS FULL-AUTO TRADING - Template Version
 * 
 * ⚠️ SETUP REQUIRED:
 * 1. Set environment variables: TOKEN and ACCOUNT_ID
 * 2. Run: source .env && node iris-full-auto-template.js &
 * 
 * 🔐 SECURITY:
 * - Do NOT hardcode credentials
 * - Use environment variables ONLY
 * - Never commit .env to git
 * 
 * 📊 EXECUTION:
 * - Runs every 1 minute via CRON
 * - PHASE 1: Trade analysis (15-20 sec)
 * - PHASE 2: Validate 8 conditions (1-2 sec)
 * - PHASE 3: Execute trade (5-10 sec)
 * - PHASE 3B: Final verify (1-2 sec)
 */

let MetaApi = require('metaapi.cloud-sdk').default;

// 🔴 GET CREDENTIALS FROM ENVIRONMENT
let token = process.env.TOKEN;
let accountId = process.env.ACCOUNT_ID;

// 🔴 VALIDATE CREDENTIALS
if (!token || !accountId) {
  console.error('\n❌ ERROR: Missing environment variables!\n');
  console.error('Setup:');
  console.error('  1. Edit .env with your credentials');
  console.error('  2. Run: source .env');
  console.error('  3. Run: node iris-full-auto-template.js &\n');
  process.exit(1);
}

const SYMBOL = 'XAUUSD.sml';
const api = new MetaApi(token);

// Daily tracking (in-memory, resets per UTC day)
let dailyState = {
  tradeCount: 0,
  dailyPnL: 0,
  isHalted: false
};

async function selectLotSize(calculatedSize) {
  const LOT_OPTIONS = [0.001, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.10, 
                       0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.00,
                       2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00];
  if (calculatedSize < 0.001) return 0.001;
  let closestLower = null;
  for (let i = LOT_OPTIONS.length - 1; i >= 0; i--) {
    if (LOT_OPTIONS[i] <= calculatedSize) {
      closestLower = LOT_OPTIONS[i];
      break;
    }
  }
  return closestLower || 0.001;
}

// 🔴 PHASE 1: Trade Check (STEP 0-10)
async function runTradeCheck(connection) {
  console.log('\n========== PHASE 1: TRADE CHECK (STEP 0-10) ==========\n');
  
  try {
    const symbolPrice = await connection.getSymbolPrice(SYMBOL);
    const entry = (symbolPrice.bid + symbolPrice.ask) / 2;
    
    console.log(`⭐ STEP 1: Entry = ${entry.toFixed(2)}`);

    // Chart analysis
    let deals = [];
    try {
      deals = await connection.getDealsByTimeRange(
        new Date(Date.now() - 24 * 60 * 60 * 1000),
        new Date()
      );
    } catch (e) { }
    
    let prices = [symbolPrice.bid, symbolPrice.ask, entry];
    if (deals && deals.length > 0) {
      prices = prices.concat(deals.map(d => d.executionPrice || d.price));
    }
    
    const volatility = Math.max(Math.max(...prices) - Math.min(...prices), 20);
    const trend = entry > ((Math.max(...prices) + Math.min(...prices)) / 2) ? 'UP' : 'DOWN';
    
    console.log(`⭐ STEP 2: Volatility = ${volatility.toFixed(2)}, Trend = ${trend}`);

    // Dynamic SL/TP
    const slBuffer = volatility * 0.20;
    const tpBuffer = volatility * 0.50;
    let sl, tp, signalType;
    
    if (trend === 'DOWN') {
      sl = entry + slBuffer;
      tp = entry - tpBuffer;
      signalType = 'SELL';
    } else {
      sl = entry - slBuffer;
      tp = entry + tpBuffer;
      signalType = 'BUY';
    }
    
    const slPoints = Math.abs(sl - entry);
    const tpPoints = Math.abs(tp - entry);
    
    console.log(`⭐ STEP 3: SL = ${sl.toFixed(2)}, TP = ${tp.toFixed(2)}`);

    // Position check
    const positions = await connection.getPositions();
    const orders = await connection.getOrders();
    
    console.log(`⭐ STEP 4: Positions = ${positions.length}, Orders = ${orders.length}`);
    
    if (positions.length > 0 || orders.length > 0) {
      console.log('❌ Position/order already open');
      return { success: false, reason: 'Position already open' };
    }

    // R/R ratio
    const ratio = tpPoints / slPoints;
    console.log(`⭐ STEP 6: R/R = ${ratio.toFixed(2)} : 1`);
    
    if (ratio < 1.0) {
      return { success: false, reason: 'R/R < 1.0' };
    }

    // Position sizing
    const accountInfo = await connection.getAccountInformation();
    const riskAmount = accountInfo.balance * 0.02;
    let lotSize = await selectLotSize(riskAmount / slPoints);
    
    console.log(`⭐ STEP 7: Lot Size = ${lotSize}`);

    // Signal strength
    let score = 4;
    if (ratio >= 1.5) score += 2;
    if (volatility > 50) score += 1;
    
    let strength = 'WEAK';
    if (score >= 6) strength = 'STRONG';
    else if (score >= 4) strength = 'MEDIUM';
    
    console.log(`⭐ STEP 8: Signal Strength = ${strength} (${score}/10)`);
    
    if (strength === 'WEAK') {
      return { success: false, reason: 'Signal too weak' };
    }

    return {
      success: true,
      signalType: signalType,
      signalStrength: strength,
      entry: entry,
      sl: sl,
      tp: tp,
      slPoints: slPoints,
      tpPoints: tpPoints,
      rrRatio: ratio,
      lotSize: lotSize,
      balance: accountInfo.balance,
      equity: accountInfo.equity
    };

  } catch (error) {
    console.error('❌ Phase 1 Error:', error.message);
    return { success: false, reason: error.message };
  }
}

// 🔴 PHASE 2: Validate 8 Conditions
async function checkFullAutoConditions(tradeCheckResult) {
  console.log('\n========== PHASE 2: VALIDATE 8 CONDITIONS ==========\n');
  
  try {
    if (!tradeCheckResult.success) {
      console.log(`❌ Phase 1 failed: ${tradeCheckResult.reason}`);
      return { canExecute: false };
    }

    // Condition 1: Signal
    if (tradeCheckResult.signalStrength === 'WEAK') {
      console.log('❌ Condition 1: Signal too weak');
      return { canExecute: false };
    }
    console.log('✅ Condition 1: Signal >= MEDIUM');

    // Condition 2: SL Points
    if (tradeCheckResult.slPoints > 100) {
      console.log('❌ Condition 2: SL > 100 points');
      return { canExecute: false };
    }
    console.log(`✅ Condition 2: SL = ${tradeCheckResult.slPoints.toFixed(2)} points`);

    // Condition 3: Risk
    console.log('✅ Condition 3: Risk = 2%');

    // Condition 4: R/R
    if (tradeCheckResult.rrRatio < 1.0) {
      console.log('❌ Condition 4: R/R < 1.0');
      return { canExecute: false };
    }
    console.log('✅ Condition 4: R/R >= 1.0');

    // Condition 5: Orders
    console.log('✅ Condition 5: Orders = UNLIMITED');

    // Condition 6: Daily Loss
    const maxDailyLoss = tradeCheckResult.balance * (-0.20);
    if (dailyState.dailyPnL <= maxDailyLoss) {
      console.log('❌ Condition 6: Daily loss limit hit');
      return { canExecute: false };
    }
    console.log('✅ Condition 6: Daily loss > -20%');

    // Condition 7: Equity
    if (tradeCheckResult.equity < 0.10) {
      console.log('❌ Condition 7: Equity too low');
      return { canExecute: false };
    }
    console.log('✅ Condition 7: Equity >= $0.10');

    // Condition 8: Balance
    if (tradeCheckResult.balance < 0.05) {
      console.log('❌ Condition 8: Balance too low');
      return { canExecute: false };
    }
    console.log('✅ Condition 8: Balance >= $0.05');

    console.log('\n========== PHASE 2: ALL CONDITIONS PASS ✅ ==========\n');
    return { canExecute: true };

  } catch (error) {
    console.error('❌ Phase 2 Error:', error.message);
    return { canExecute: false };
  }
}

// 🔴 PHASE 3: Execute Trade
async function executeTrade(tradeData, connection) {
  console.log('\n========== PHASE 3: EXECUTE TRADE ==========\n');
  
  try {
    const { signalType, entry, sl, tp, lotSize } = tradeData;
    
    console.log(`⭐ Creating ${signalType} order`);
    console.log(`   Entry: ${entry.toFixed(2)}`);
    console.log(`   SL: ${sl.toFixed(2)}`);
    console.log(`   TP: ${tp.toFixed(2)}`);
    console.log(`   Lot: ${lotSize}`);

    let order;
    try {
      let orderParams = {
        stopLoss: sl,
        takeProfit: tp,
        comment: `Iris ${signalType} ${Date.now()}`
      };

      if (signalType === 'BUY') {
        order = await connection.createMarketBuyOrder(SYMBOL, lotSize, orderParams);
      } else {
        order = await connection.createMarketSellOrder(SYMBOL, lotSize, orderParams);
      }

      console.log(`✅ Order created: ${order.orderId}`);
      dailyState.tradeCount++;

      return { success: true, orderId: order.orderId };

    } catch (error) {
      if (error.message.includes('insufficient') || error.message.includes('margin')) {
        console.log(`⚠️ Insufficient margin, retrying with 0.001 lot`);
        
        let fallbackOrder;
        if (signalType === 'BUY') {
          fallbackOrder = await connection.createMarketBuyOrder(SYMBOL, 0.001, {
            stopLoss: sl,
            takeProfit: tp,
            comment: `Iris ${signalType} Fallback`
          });
        } else {
          fallbackOrder = await connection.createMarketSellOrder(SYMBOL, 0.001, {
            stopLoss: sl,
            takeProfit: tp,
            comment: `Iris ${signalType} Fallback`
          });
        }

        console.log(`✅ Fallback order created: ${fallbackOrder.orderId}`);
        dailyState.tradeCount++;
        return { success: true, orderId: fallbackOrder.orderId };
      }
      
      throw error;
    }

  } catch (error) {
    console.error('❌ Phase 3 Error:', error.message);
    return { success: false, reason: error.message };
  }
}

// Main execution
async function fullAutoTrade() {
  try {
    console.log('═══════════════════════════════════════════');
    console.log('🤖 IRIS FULL-AUTO TRADING (Template)');
    console.log('═══════════════════════════════════════════');

    const account = await api.metatraderAccountApi.getAccount(accountId);
    
    if (!['DEPLOYING', 'DEPLOYED'].includes(account.state)) {
      await account.deploy();
    }

    await account.waitConnected();
    let connection = account.getRPCConnection();
    await connection.connect();
    await connection.waitSynchronized();

    // Phase 1
    const tradeCheckResult = await runTradeCheck(connection);

    if (!tradeCheckResult.success) {
      console.log(`\n❌ Trade check failed: ${tradeCheckResult.reason}`);
      await connection.close();
      return;
    }

    // Phase 2
    const fullAutoCheck = await checkFullAutoConditions(tradeCheckResult);

    if (!fullAutoCheck.canExecute) {
      console.log('\n❌ Conditions not met');
      await connection.close();
      return;
    }

    // Phase 3
    const executionResult = await executeTrade(tradeCheckResult, connection);

    if (!executionResult.success) {
      console.log(`\n❌ Execution failed: ${executionResult.reason}`);
      await connection.close();
      return;
    }

    // Phase 3B: Verify
    console.log('\n========== PHASE 3B: FINAL VERIFICATION ==========\n');
    try {
      const finalVerify = await connection.getOrder(executionResult.orderId);
      if (finalVerify && finalVerify.id) {
        console.log(`✅ ORDER VERIFIED: ${finalVerify.id}`);
        console.log('\n✅ EXECUTION COMPLETE\n');
      }
    } catch (e) {
      console.log(`⚠️ Verification warning: ${e.message}`);
    }

    await connection.close();

  } catch (error) {
    console.error('❌ FATAL ERROR:', error.message);
  }
}

fullAutoTrade();
