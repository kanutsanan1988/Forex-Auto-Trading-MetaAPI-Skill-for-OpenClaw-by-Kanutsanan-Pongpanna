#!/usr/bin/env node

/**
 * IRIS TRADE CHECK - Template Version
 * 
 * ⚠️ SETUP REQUIRED:
 * 1. Set environment variables: TOKEN and ACCOUNT_ID
 * 2. Run: source .env && node iris-trade-check-template.js
 * 
 * 🔐 SECURITY:
 * - Do NOT hardcode credentials
 * - Use environment variables ONLY
 * - Never commit .env to git
 */

let MetaApi = require('metaapi.cloud-sdk').default;

// 🔴 GET CREDENTIALS FROM ENVIRONMENT (NOT HARDCODED)
let token = process.env.TOKEN;
let accountId = process.env.ACCOUNT_ID;

// 🔴 VALIDATE CREDENTIALS
if (!token || !accountId) {
  console.error('\n❌ ERROR: Missing required environment variables!\n');
  console.error('Setup Instructions:');
  console.error('  1. Edit .env file with your credentials');
  console.error('  2. Run: source .env');
  console.error('  3. Run: node iris-trade-check-template.js\n');
  console.error('Example .env:');
  console.error('  export TOKEN="your-metaapi-key-here"');
  console.error('  export ACCOUNT_ID="your-account-id-here"\n');
  process.exit(1);
}

const SYMBOL = 'XAUUSD.sml';
const api = new MetaApi(token);

async function selectLotSize(calculatedSize) {
  const LOT_OPTIONS = [0.001, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.10, 
                       0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.00,
                       2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00];
  
  if (calculatedSize < 0.001) return 0.001;
  
  let closestLower = null;
  for (let i = LOT_OPTIONS.length - 1; i >= 0; i--) {
    if (LOT_OPTIONS[i] <= calculatedSize) {
      closestLower = LOT_OPTIONS[i];
      break;
    }
  }
  
  return closestLower || 0.001;
}

async function checkTrade() {
  try {
    console.log('\n═══════════════════════════════════════════');
    console.log('🤖 IRIS TRADE CHECK (Template Version)');
    console.log('═══════════════════════════════════════════\n');

    const account = await api.metatraderAccountApi.getAccount(accountId);
    const initialState = account.state;
    const deployedStates = ['DEPLOYING', 'DEPLOYED'];

    if(!deployedStates.includes(initialState)) {
      console.log('📊 กำลังดำเนินการ Deployment...');
      await account.deploy();
    }
  
    console.log('⏳ รอให้ API เชื่อมต่อ...');
    await account.waitConnected();

    let connection = account.getRPCConnection();
    await connection.connect();

    console.log('⏳ รอให้ SDK ซิงโครไนซ์...');
    await connection.waitSynchronized();

    // ✅ STEP 0: Market Status
    console.log('\n🔴 STEP 0: ตรวจสอบตลาดเปิด');
    const symbolPrice = await connection.getSymbolPrice(SYMBOL);
    console.log(`  Bid: ${symbolPrice.bid}, Ask: ${symbolPrice.ask}`);

    // ✅ STEP 1: Fresh Entry Price (Real-time)
    console.log('\n🔴 STEP 1: ดึงราคา Entry ที่ REAL-TIME');
    const entry = (symbolPrice.bid + symbolPrice.ask) / 2;
    console.log(`  Entry Price: ${entry}`);

    // ✅ STEP 2: Chart Analysis (API only)
    console.log('\n🔴 STEP 2: วิเคราะห์กราฟ (getDealsByTimeRange)');
    let deals = [];
    try {
      deals = await connection.getDealsByTimeRange(
        new Date(Date.now() - 24 * 60 * 60 * 1000),
        new Date()
      );
    } catch (e) {
      console.log(`  (No deal history in 24h)`);
    }
    
    let prices = [symbolPrice.bid, symbolPrice.ask, entry];
    if (deals && deals.length > 0) {
      prices = prices.concat(deals.map(d => d.executionPrice || d.price));
    }
    
    const highestPrice = Math.max(...prices);
    const lowestPrice = Math.min(...prices);
    const resistance = highestPrice;
    const support = lowestPrice;
    const volatility = Math.max(resistance - support, 20);
    
    console.log(`  Support: ${support.toFixed(2)}, Resistance: ${resistance.toFixed(2)}`);
    console.log(`  Volatility: ${volatility.toFixed(2)} points`);
    
    const trend = entry > (support + resistance) / 2 ? 'UP' : 'DOWN';
    console.log(`  Trend: ${trend}`);

    // ✅ STEP 3: Dynamic SL/TP
    console.log('\n🔴 STEP 3: คำนวณ SL & TP (DYNAMIC)');
    const effectiveVolatility = volatility > 0 ? volatility : 20;
    const slBuffer = effectiveVolatility * 0.20;
    const tpBuffer = effectiveVolatility * 0.50;
    
    let sl, tp, signalType;
    if (trend === 'DOWN') {
      sl = entry + slBuffer;
      tp = entry - tpBuffer;
      signalType = 'SELL';
    } else {
      sl = entry - slBuffer;
      tp = entry + tpBuffer;
      signalType = 'BUY';
    }
    
    const slPoints = Math.abs(sl - entry);
    const tpPoints = Math.abs(tp - entry);
    
    console.log(`  Signal: ${signalType}`);
    console.log(`  SL: ${sl.toFixed(2)} (${slPoints.toFixed(2)} points)`);
    console.log(`  TP: ${tp.toFixed(2)} (${tpPoints.toFixed(2)} points)`);

    // ✅ STEP 4: Position Check
    console.log('\n🔴 STEP 4: ตรวจสอบ Position (One-at-a-time)');
    const positions = await connection.getPositions();
    const orders = await connection.getOrders();
    
    console.log(`  Positions: ${positions.length}, Orders: ${orders.length}`);
    
    if (positions.length > 0 || orders.length > 0) {
      console.log('  ⚠️ Position or order already open');
      if (positions.length > 0) {
        const oldPosition = positions[0];
        const oldTrend = oldPosition.type === 'POSITION_TYPE_BUY' ? 'UP' : 'DOWN';
        console.log(`  Old Trend: ${oldTrend}, New Trend: ${trend}`);
      }
      return;
    }
    
    console.log('  ✅ Ready to trade (no open positions)');

    // ✅ STEP 5: Validate SL/TP
    console.log('\n🔴 STEP 5: ตรวจสอบ SL/TP');
    let slValid = false;
    if (signalType === 'BUY' && sl < entry && tp > entry) {
      slValid = true;
      console.log('  ✅ BUY: SL < Entry < TP');
    } else if (signalType === 'SELL' && sl > entry && tp < entry) {
      slValid = true;
      console.log('  ✅ SELL: TP < Entry < SL');
    }
    
    if (!slValid) {
      console.log('  ❌ SL/TP direction invalid');
      return;
    }

    // ✅ STEP 6: Risk/Reward
    console.log('\n🔴 STEP 6: Risk/Reward Ratio');
    const risk = Math.abs(entry - sl);
    const reward = Math.abs(tp - entry);
    const ratio = reward / risk;
    console.log(`  Risk: ${risk.toFixed(2)} points`);
    console.log(`  Reward: ${reward.toFixed(2)} points`);
    console.log(`  R/R Ratio: ${ratio.toFixed(2)} : 1`);
    
    if (ratio < 1.0) {
      console.log('  ⚠️ R/R ratio < 1.0 - Signal too weak');
      return;
    }

    // ✅ STEP 7: Position Sizing
    console.log('\n🔴 STEP 7: Position Sizing (2% Risk)');
    const accountInfo = await connection.getAccountInformation();
    const balance = accountInfo.balance;
    const riskAmount = balance * 0.02;
    const calculatedSize = riskAmount / slPoints;
    const selectedLot = await selectLotSize(calculatedSize);
    
    console.log(`  Balance: $${balance.toFixed(4)}`);
    console.log(`  Risk (2%): $${riskAmount.toFixed(4)}`);
    console.log(`  Selected Lot: ${selectedLot}`);

    // ✅ STEP 8: Signal Strength
    console.log('\n🔴 STEP 8: Signal Strength');
    let score = 4;
    if (ratio >= 1.5) score += 2;
    if (volatility > 50) score += 1;
    
    let strength = 'WEAK';
    if (score >= 6) strength = 'STRONG';
    else if (score >= 4) strength = 'MEDIUM';
    
    console.log(`  Score: ${score}/10 = ${strength}`);

    // ✅ STEP 9: Verification
    console.log('\n🔴 STEP 9: Final Verification');
    console.log('  ✅ All API data verified');

    // ✅ STEP 10: Recommendation
    console.log('\n🔴 STEP 10: Trade Recommendation');
    console.log(`\n✅ TRADE READY: ${strength} ${signalType}`);
    console.log(`   Entry: ${entry.toFixed(2)}`);
    console.log(`   SL: ${sl.toFixed(2)}`);
    console.log(`   TP: ${tp.toFixed(2)}`);
    console.log(`   Lot: ${selectedLot}`);
    console.log(`   R/R: ${ratio.toFixed(2)}\n`);

    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

checkTrade();
