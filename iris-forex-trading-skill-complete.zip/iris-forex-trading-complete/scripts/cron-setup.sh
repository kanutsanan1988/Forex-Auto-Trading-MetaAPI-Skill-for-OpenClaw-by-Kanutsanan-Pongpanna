#!/bin/bash

# ═══════════════════════════════════════════
# IRIS FOREX TRADING - CRON Setup
# ═══════════════════════════════════════════

set -e

echo ""
echo "╔════════════════════════════════════════╗"
echo "║  IRIS CRON - Automatic Trading Setup   ║"
echo "╚════════════════════════════════════════╝"
echo ""

# 1. Verify environment
echo "🔍 Checking environment variables..."
if [ -z "$TOKEN" ] || [ -z "$ACCOUNT_ID" ]; then
  echo "❌ ERROR: Missing TOKEN or ACCOUNT_ID"
  echo ""
  echo "Run first:"
  echo "  source .env"
  echo ""
  exit 1
fi
echo "✅ Environment variables loaded"

# 2. Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

echo "📁 Project directory: $PROJECT_DIR"

# 3. Create logs directory
echo ""
echo "📂 Creating logs directory..."
mkdir -p "$PROJECT_DIR/logs"
echo "✅ Logs directory created"

# 4. Remove old cron jobs
echo ""
echo "🗑️  Removing old CRON jobs..."
crontab -l 2>/dev/null | grep -v "iris" | crontab - 2>/dev/null || true
echo "✅ Old jobs removed"

# 5. Create new CRON jobs
echo ""
echo "⚙️  Creating new CRON jobs..."

# Create temporary crontab file
TEMP_CRON=$(mktemp)
crontab -l 2>/dev/null > "$TEMP_CRON" || echo "" > "$TEMP_CRON"

# Add Iris jobs
cat >> "$TEMP_CRON" << EOF

# ═══════════════════════════════════════════
# IRIS FOREX TRADING - Automatic Execution
# Do not edit manually - regenerate with: bash scripts/cron-setup.sh
# ═══════════════════════════════════════════

# Sunday evening trading
0 23 * * 0 cd $PROJECT_DIR && source .env && node scripts/iris-full-auto-template.js >> logs/iris-sunday.log 2>&1

# Mon-Fri main trading (every 1 minute 00:00-21:59 UTC)
*/1 0-21 * * 1-5 cd $PROJECT_DIR && source .env && node scripts/iris-full-auto-template.js >> logs/iris-main.log 2>&1

# Friday close trading
0 22 * * 5 cd $PROJECT_DIR && source .env && node scripts/iris-full-auto-template.js >> logs/iris-friday.log 2>&1

EOF

# Install the new crontab
crontab "$TEMP_CRON"
rm "$TEMP_CRON"

echo "✅ CRON jobs installed"

# 6. Display setup summary
echo ""
echo "═══════════════════════════════════════════"
echo "✅ CRON SETUP COMPLETE"
echo "═══════════════════════════════════════════"
echo ""
echo "📋 Installed jobs:"
echo ""
crontab -l 2>/dev/null | grep "iris" | sed 's/^/   /'
echo ""
echo "📁 Log files:"
echo "   • logs/iris-sunday.log"
echo "   • logs/iris-main.log"
echo "   • logs/iris-friday.log"
echo ""
echo "🔍 Monitor trading:"
echo "   tail -f logs/iris-main.log"
echo ""
echo "🛑 Stop CRON:"
echo "   crontab -r"
echo ""
echo "ℹ️  Schedule:"
echo "   • Every 1 minute, Mon-Fri 00:00-21:59 UTC"
echo "   • Plus Sunday 23:00 & Friday 22:00"
echo "   • Total: ~6,361 runs per week"
echo ""
