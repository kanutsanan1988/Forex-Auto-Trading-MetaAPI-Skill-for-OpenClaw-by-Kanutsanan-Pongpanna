#!/bin/bash

# ═══════════════════════════════════════════
# IRIS FOREX TRADING - Setup Script
# ═══════════════════════════════════════════

set -e

echo ""
echo "╔════════════════════════════════════════╗"
echo "║  IRIS FOREX TRADING - Setup Wizard     ║"
echo "╚════════════════════════════════════════╝"
echo ""

# 1. Check Node.js
echo "🔍 Checking Node.js installation..."
if ! command -v node &> /dev/null; then
  echo "❌ Node.js not found. Please install Node.js 14+ first:"
  echo "   https://nodejs.org/"
  exit 1
fi
NODE_VERSION=$(node -v)
echo "✅ Node.js $NODE_VERSION found"

# 2. Install dependencies
echo ""
echo "📦 Installing dependencies..."
npm install
echo "✅ Dependencies installed"

# 3. Setup .env
echo ""
echo "🔑 Setting up configuration..."

if [ -f ".env" ]; then
  echo "ℹ️  .env file already exists"
  read -p "Overwrite? (y/n) " -n 1 -r
  echo
  if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "✅ Using existing .env"
  else
    cp assets/config-template.env .env
    echo "✅ Created new .env from template"
  fi
else
  cp assets/config-template.env .env
  echo "✅ Created .env from template"
fi

# 4. Guide user to fill .env
echo ""
echo "📝 Next steps:"
echo ""
echo "1️⃣  Edit your .env file with your MetaApi credentials:"
echo "   nano .env"
echo ""
echo "   You need:"
echo "   • TOKEN: Your MetaApi API Key from https://app.metaapi.cloud"
echo "   • ACCOUNT_ID: Your MetaApi Account ID"
echo ""
echo "2️⃣  Load the environment variables:"
echo "   source .env"
echo ""
echo "3️⃣  Test the connection:"
echo "   node scripts/iris-trade-check-template.js"
echo ""
echo "4️⃣  (Optional) Setup automatic trading:"
echo "   bash scripts/cron-setup.sh"
echo ""
echo "✅ Setup wizard complete!"
echo ""
