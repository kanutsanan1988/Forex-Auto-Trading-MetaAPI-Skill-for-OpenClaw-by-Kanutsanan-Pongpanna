# CRON Scheduling - Complete Guide

Automated execution every 1 minute with professional-grade scheduling.

## Quick Setup

```bash
# 1. Make setup scripts executable
chmod +x scripts/cron-setup.sh

# 2. Run setup
source .env
scripts/cron-setup.sh

# 3. Verify
crontab -l | grep iris

# 4. Stop (if needed)
crontab -r
```

## Schedule Overview

**Frequency:** Every 1 minute
**Total Runs:** 6,361 per week
**Execution Time:** ~33 seconds per cycle

### 3 CRON Jobs

#### Job 1: Sunday Evening
```
Schedule: 0 23 * * 0
Time: Every Sunday at 23:00-23:59 UTC
Runs: 60 per week
Purpose: Catch weekend closing opportunities
```

#### Job 2: Mon-Fri Main (PRIMARY)
```
Schedule: */1 0-21 * * 1-5
Time: Mon-Fri 00:00-21:59 UTC
Runs: 6,300 per week
Purpose: Main trading hours
```

#### Job 3: Friday Close
```
Schedule: 0 22 * * 5
Time: Friday at 22:00 UTC
Runs: 1 per week
Purpose: Final trading window
```

**Total:** 6,361 runs/week

---

## Execution Timeline

Each cycle takes exactly 60 seconds:

```
Minute 0:00
  ├─ 0-2 sec: CRON triggers
  │
  ├─ 2-20 sec: PHASE 1
  │   └─ STEP 0-10 analysis (15-20 sec)
  │
  ├─ 20-22 sec: PHASE 2
  │   └─ Validate 8 conditions (1-2 sec)
  │
  ├─ 22-32 sec: PHASE 3
  │   └─ Execute trade (5-10 sec)
  │
  ├─ 32-34 sec: PHASE 3B
  │   └─ Final verify (1-2 sec)
  │
  └─ 34-60 sec: Wait
      └─ Ready for next cycle

Minute 1:00: Repeat
```

---

## Implementation

### Option 1: System CRON (Recommended)

Setup with system crontab:

```bash
# Edit crontab
crontab -e

# Add these lines:

# Iris Trading - Sunday evening
0 23 * * 0 source /path/to/.env && node /path/to/iris-full-auto.js >> /path/to/iris-sunday.log 2>&1

# Iris Trading - Mon-Fri main
*/1 0-21 * * 1-5 source /path/to/.env && node /path/to/iris-full-auto.js >> /path/to/iris-main.log 2>&1

# Iris Trading - Friday close
0 22 * * 5 source /path/to/.env && node /path/to/iris-full-auto.js >> /path/to/iris-friday.log 2>&1
```

### Option 2: Node CRON (Alternative)

Use node-cron package:

```javascript
const cron = require('node-cron');

// Every minute
cron.schedule('*/1 * * * *', () => {
  fullAutoTrade();
});

// Log running
console.log('✅ CRON scheduled: Every 1 minute');
```

### Option 3: PM2 (Production)

Use PM2 for process management:

```bash
# Install PM2
npm install -g pm2

# Create ecosystem.config.js
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'iris-trading',
    script: './scripts/iris-full-auto-template.js',
    instances: 1,
    watch: false,
    max_memory_restart: '500M',
    env: {
      TOKEN: process.env.TOKEN,
      ACCOUNT_ID: process.env.ACCOUNT_ID
    }
  }]
};
EOF

# Start
pm2 start ecosystem.config.js

# Monitor
pm2 monit
```

---

## Status & Monitoring

### Check if CRON is Running

```bash
# List all cron jobs
crontab -l | grep iris

# Check system logs
tail -f /var/log/syslog | grep CRON

# Verify execution
ls -lh iris-*.log
tail -f iris-main.log
```

### Log Files

Each job logs to separate file:

```
iris-sunday.log    → Sunday evening runs
iris-main.log      → Mon-Fri main runs
iris-friday.log    → Friday close runs
```

### Monitor Output

```bash
# Watch main trading log live
tail -f iris-main.log

# Check for errors
grep "❌" iris-main.log

# Count daily trades
grep "✅ Order created" iris-main.log | wc -l
```

---

## Troubleshooting

### Issue: CRON not running

**Diagnosis:**
```bash
# Check cron service
sudo service cron status

# Check crontab syntax
crontab -l | grep iris
```

**Fix:**
```bash
# Restart cron service
sudo service cron restart

# Or add job again
crontab -e
# (re-add the iris lines)
```

### Issue: Jobs running but not executing code

**Diagnosis:**
```bash
# Check environment variables
echo $TOKEN
echo $ACCOUNT_ID

# Check logs
tail -f iris-main.log
```

**Fix:**
```bash
# Ensure .env is sourced in cron
# Use full paths:

0 23 * * 0 cd /home/user/iris && source .env && node scripts/iris-full-auto-template.js >> iris-sunday.log 2>&1
```

### Issue: API connection failures

**Diagnosis:**
```bash
# Test API connection manually
source .env
node scripts/iris-trade-check-template.js
```

**Fix:**
- Verify API Key is valid
- Verify Account ID is correct
- Check MetaApi status: https://app.metaapi.cloud
- Ensure account is deployed and connected

---

## Best Practices

### 1. Use Separate Logs

```bash
# Each job to its own log
0 23 * * 0 ... >> /logs/iris-sunday.log 2>&1
*/1 0-21 * * 1-5 ... >> /logs/iris-main.log 2>&1
0 22 * * 5 ... >> /logs/iris-friday.log 2>&1
```

### 2. Add Health Checks

```bash
# Before running job
*/1 * * * * /scripts/health-check.sh && node iris-full-auto.js
```

### 3. Monitor Daily

```bash
# Review logs daily
#!/bin/bash
TODAY=$(date +%Y-%m-%d)

echo "=== Trading Summary for $TODAY ==="
echo "Total trades: $(grep 'Order created' iris-main.log | wc -l)"
echo "Successful: $(grep '✅' iris-main.log | wc -l)"
echo "Failed: $(grep '❌' iris-main.log | wc -l)"
echo "Errors: $(grep 'Error' iris-main.log | wc -l)"
```

### 4. Backup Logs Regularly

```bash
# Weekly backup
0 0 * * 0 tar -czf /backups/iris-logs-$(date +%Y-%m-%d).tar.gz /logs/iris-*.log
```

### 5. Email Alerts (Optional)

```bash
# Alert on error
*/1 * * * * grep "ERROR" iris-main.log && echo "Trading error!" | mail -s "Iris Alert" user@example.com
```

---

## Performance Metrics

### Expected Performance

```
Execution time per cycle: ~33 seconds
  ├─ PHASE 1: 15-20 sec
  ├─ PHASE 2: 1-2 sec
  ├─ PHASE 3: 5-10 sec
  └─ PHASE 3B: 1-2 sec

Cycle frequency: Every 60 seconds
Reliability: 99%+ (dependent on API uptime)

Weekly runs: 6,361
Success rate: Target 90%+
```

### Resource Usage

```
Memory: ~50-100 MB per process
CPU: Minimal (spikes during execution)
API Calls: ~15-20 per cycle
Network: ~1-2 KB per execution
```

---

## Disaster Recovery

### If CRON dies

```bash
# Restart manually
nohup /scripts/iris-full-auto.sh &

# Or use PM2
pm2 resurrect
```

### If server restarts

```bash
# Add to /etc/rc.local
crontab /home/user/crontab.backup
service cron start
```

### Backup crontab

```bash
# Save crontab
crontab -l > /backups/crontab.backup

# Restore from backup
crontab /backups/crontab.backup
```

---

## Complete Setup Script

```bash
#!/bin/bash
# iris-cron-setup.sh

set -e

echo "🔄 Setting up Iris Trading CRON..."

# 1. Validate environment
if [ -z "$TOKEN" ] || [ -z "$ACCOUNT_ID" ]; then
  echo "❌ ERROR: Missing TOKEN or ACCOUNT_ID"
  echo "   Run: source .env"
  exit 1
fi

echo "✅ Environment variables loaded"

# 2. Create log directory
mkdir -p logs

# 3. Remove old jobs
crontab -r 2>/dev/null || true

# 4. Create new jobs
(
  crontab -l 2>/dev/null || echo ""
  echo "# Iris Trading System - Do not edit manually"
  echo "# Sunday evening"
  echo "0 23 * * 0 source $PWD/.env && node $PWD/scripts/iris-full-auto-template.js >> $PWD/logs/iris-sunday.log 2>&1"
  echo "# Mon-Fri main trading"
  echo "*/1 0-21 * * 1-5 source $PWD/.env && node $PWD/scripts/iris-full-auto-template.js >> $PWD/logs/iris-main.log 2>&1"
  echo "# Friday close"
  echo "0 22 * * 5 source $PWD/.env && node $PWD/scripts/iris-full-auto-template.js >> $PWD/logs/iris-friday.log 2>&1"
) | crontab -

echo "✅ CRON jobs installed"

# 5. Verify
echo ""
echo "📋 Current CRON jobs:"
crontab -l | grep iris

echo ""
echo "✅ Setup complete!"
echo "   Logs: $PWD/logs/"
echo "   Monitor: tail -f logs/iris-main.log"
```

---

## Timezone Considerations

### UTC Schedule

All times in documentation are UTC. To convert:

```
UTC 00:00 = 8:00 AM Bangkok (UTC+7)
UTC 23:00 = 6:00 AM Bangkok (next day)
```

### Set Timezone in CRON

```bash
# Add timezone to crontab
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
TZ=UTC

# Then add jobs as normal
0 23 * * 0 source .env && node iris-full-auto.js >> iris-sunday.log 2>&1
```

---

## Summary

| Item | Value |
|------|-------|
| Frequency | Every 1 minute |
| Runs/week | 6,361 |
| Jobs | 3 (Sun, Mon-Fri, Fri) |
| Execution time | ~33 seconds |
| Cycle time | 60 seconds |
| Logs | Separate per job |
| Status | Production-ready |

Ready to trade 24/7 automatically! 🚀
