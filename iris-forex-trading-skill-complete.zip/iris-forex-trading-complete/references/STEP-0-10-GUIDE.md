# STEP 0-10 Complete Guide

Trade analysis workflow with detailed explanations of each step.

## STEP 0: Market Status Check

**Purpose:** Verify market is open and API is responsive

**API Call:** `getSymbolPrice(SYMBOL)`

**What it does:**
- Fetches current bid/ask prices from broker
- Confirms market is trading
- Gets real-time data

**Example output:**
```
Bid: 5155.23
Ask: 5155.95
```

---

## STEP 1: Fresh Entry Price

**Purpose:** Get the exact entry price to use for calculations

**Calculation:** `(bid + ask) / 2` = mid-price

**Important:**
- Fresh every cycle (not cached)
- Real-time from API
- Mid-point between bid/ask

**Example:**
```
Bid: 5155.23
Ask: 5155.95
Entry: 5155.59
```

---

## STEP 2: Chart Analysis

**Purpose:** Analyze recent price action to understand volatility and trend

**API Call:** `getDealsByTimeRange()` (24-hour history)

**What it calculates:**
- Support (lowest price in 24h)
- Resistance (highest price in 24h)
- Volatility = Resistance - Support
- Trend = which side of midpoint

**Example:**
```
Support: 5039.78
Resistance: 5155.95
Volatility: 116.17 points
Trend: UP (entry above midpoint)
```

---

## STEP 3: Dynamic SL & TP Calculation

**Purpose:** Set stop loss and take profit dynamically based on volatility

**Formulas:**
```
SL Buffer = Volatility × 0.20 (20%)
TP Buffer = Volatility × 0.50 (50%)
```

**For SELL signal (Trend DOWN):**
```
SL = Entry + SL Buffer (above)
TP = Entry - TP Buffer (below)
```

**For BUY signal (Trend UP):**
```
SL = Entry - SL Buffer (below)
TP = Entry + TP Buffer (above)
```

**Example (SELL):**
```
Entry: 5155.59
Volatility: 116.17
SL Buffer: 23.23 points
TP Buffer: 58.09 points

SL = 5155.59 + 23.23 = 5178.82
TP = 5155.59 - 58.09 = 5097.50
```

---

## STEP 4: Position Check with Profit Threshold

**Purpose:** Verify only one trade is open, check profit threshold if trend changes

**5 Cases:**

### CASE 1: Ready (0 positions, 0 orders)
```
Action: Can create new trade ✅
Reason: No conflicts
```

### CASE 2: Position Open (1 position, 0 orders)
```
Check: Old trend vs New trend
IF same trend:
  Action: Keep position ✅
IF opposite trend:
  Check P&L:
  IF profit >= 2%:
    Action: Close + Create new ✅
  IF loss >= 2%:
    Action: Close + Create new ✅
  IF |P&L| < 2%:
    Action: WAIT ⏸️
```

### CASE 3: Pending Order (0 positions, 1 order)
```
Action: WAIT for execution ⏸️
Reason: Cannot create multiple
```

### CASE 4: Both Open (1 position, 1 order) 
```
Action: CRITICAL - STOP ❌
Reason: Abnormal state
```

### CASE 5: Multiple (> 1 of anything)
```
Action: ERROR ❌
Reason: System violation
```

---

## STEP 5: Validate SL & TP Direction

**Purpose:** Ensure stop loss and take profit are on correct sides

**For BUY:**
```
Requirement: SL < Entry < TP
Example:
  SL: 5155.00
  Entry: 5155.59
  TP: 5156.00
  ✅ Valid
```

**For SELL:**
```
Requirement: TP < Entry < SL
Example:
  TP: 5154.00
  Entry: 5155.59
  SL: 5156.00
  ✅ Valid
```

---

## STEP 6: Risk/Reward Ratio

**Purpose:** Ensure trade has good reward relative to risk

**Calculation:**
```
Risk = |Entry - SL|
Reward = |TP - Entry|
R/R Ratio = Reward / Risk

Requirement: R/R >= 1.0
```

**Example:**
```
Entry: 5155.59
SL: 5178.82
TP: 5097.50

Risk: 23.23 points
Reward: 58.09 points
R/R: 2.5 : 1 ✅ (excellent)
```

---

## STEP 7: Position Sizing (2% Risk Rule)

**Purpose:** Calculate correct lot size for 2% risk per trade

**Calculation:**
```
Risk Amount = Balance × 2%
Lot Size = Risk Amount / SL Points

Round DOWN to valid broker lot size
Minimum: 0.001 lot
```

**Example:**
```
Balance: $0.28
Risk: 2%
Risk Amount: $0.0056

SL Points: 23.23
Calculated Lot: 0.0056 / 23.23 = 0.000241

Rounded DOWN to: 0.001 lot (minimum)
```

---

## STEP 8: Signal Strength (0-10 Scale)

**Purpose:** Score the quality of the trade signal

**Scoring:**
```
Base: 4 points
+ 2 if R/R >= 1.5
+ 1 if volatility > 50
+ 1 if volatility > 100

Total: 0-10 points
```

**Interpretation:**
```
0-3: WEAK (skip trade)
4-5: MEDIUM (trade with caution)
6-10: STRONG (good to trade)
```

**Example:**
```
Base: 4
R/R 2.5 >= 1.5: +2
Volatility 116 > 50: +1
Volatility 116 > 100: +1

Total: 8/10 = STRONG ✅
```

---

## STEP 9: Final API Verification

**Purpose:** Confirm all data came from API, no external sources

**Checks:**
- Entry price: from getSymbolPrice() ✓
- Volatility: from getDealsByTimeRange() ✓
- Positions: from getPositions() ✓
- Account info: from getAccountInformation() ✓
- NO external data sources ✓

---

## STEP 10: Trade Recommendation

**Purpose:** Summarize the complete analysis and recommend action

**Output:**
```
Signal: SELL (STRONG)
Entry: 5155.59
SL: 5178.82
TP: 5097.50
Lot: 0.001
R/R: 2.5 : 1
Status: READY ✅
```

**Decision:**
- Signal >= 6: Execute ✅
- Signal 4-5: Execute with caution
- Signal < 4: WAIT ⏸️

---

## Complete Example Trade

```
STEP 0: Market open ✓
STEP 1: Entry = 5155.59
STEP 2: Volatility = 116.17, Trend = DOWN
STEP 3: SL = 5178.82, TP = 5097.50
STEP 4: No position open, ready ✓
STEP 5: SELL direction valid ✓
STEP 6: R/R = 2.5 ✓
STEP 7: Lot = 0.001
STEP 8: Score = 8/10 = STRONG
STEP 9: API verified ✓
STEP 10: SELL STRONG - READY ✅

→ Execute trade!
```
