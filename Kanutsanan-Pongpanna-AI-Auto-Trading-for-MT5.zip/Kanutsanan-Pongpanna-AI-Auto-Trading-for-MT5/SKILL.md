---
name: Kanutsanan-Pongpanna-AI-Auto-Trading-for-MT5
description: Complete automated forex trading system for XAU/USD (gold) with real-time analysis, full-auto execution, and CRON scheduling. Manual setup required with your Account ID and API Key only. Created by Kanutsanan Pongpanna.
---

# Kanutsanan-Pongpanna-AI-Auto-Trading-for-MT5

**Complete automated trading system for MetaApi** — Manual trade check + Full-auto execution + CRON scheduling

## Quick Start (5 minutes)

### 1. Install Dependencies

```bash
npm install metaapi.cloud-sdk
```

### 2. Configure Environment Variables

Create `.env` file (see `assets/config-template.env`):

```bash
export TOKEN="YOUR_METAPI_API_KEY_HERE"
export ACCOUNT_ID="YOUR_METAPI_ACCOUNT_ID_HERE"
```

**⚠️ IMPORTANT:** 
- Get your **API Key** from: https://app.metaapi.cloud (account settings)
- Get your **Account ID** from: https://app.metaapi.cloud (select your account)
- NEVER share your credentials
- NEVER commit `.env` to git

### 3. Run Trade Check (Manual)

```bash
source .env
node kanutsanan-pongpanna-trade-check.js
```

Output: Real-time trade analysis (STEP 0-10)

### 4. Enable Full-Auto (Optional)

```bash
source .env
node kanutsanan-pongpanna-full-auto.js &
```

Runs automatically every 38 seconds via CRON.

## What This System Does

### 🔴 System 1: Trade Check (Manual)

**File:** `scripts/kanutsanan-pongpanna-trade-check-template.js`
**Time:** 15-20 seconds per check
**Use:** On-demand trade analysis

```
STEP 0: Market status check
STEP 1: Fresh entry price (real-time)
STEP 2: Chart analysis (M15 volatility)
STEP 3: Dynamic SL/TP calculation
STEP 4: Risk/Reward ratio (≥1.0)
STEP 5: Position sizing (2% rule)
STEP 6: Signal strength (0-10)
STEP 7: Validate SL/TP direction
STEP 8: Final API verification
STEP 9: Position & Order check (MOVED TO LAST)
STEP 10: Trade recommendation
```

Output:
```
Entry: 5155.24
Signal: SELL (STRONG)
SL: 5159.24
TP: 5145.24
Lot: 0.001
R/R: 2.5
Status: READY ✅
```

### 🟢 System 2: Full-Auto Execution

**File:** `scripts/kanutsanan-pongpanna-full-auto-template.js`
**Time:** ~33 seconds per cycle
**Frequency:** Every 38 seconds (via CRON)

Three phases:
- **PHASE 1:** Trade check (STEP 0-10, 15-20 sec)
- **PHASE 2:** Validate 8 conditions (1-2 sec)
- **PHASE 3:** Execute trade (5-10 sec)
- **PHASE 3B:** Final verification (1-2 sec)

### ⚙️ System 3: CRON Scheduling

**File:** `scripts/cron-setup.sh`
**Frequency:** Every 38 seconds
**Schedule:** 3 jobs (Sun/Mon-Fri/Fri)

## Understanding the System

### Trade Analysis (STEP 0-10)

1. **Real-time API data** - Fresh prices every cycle
2. **M15 Chart Analysis** - 15-minute volatility from getCandles()
3. **Dynamic SL/TP** - Calculated from volatility, NOT fixed values
4. **Professional scoring** - Signal strength 0-10 scale
5. **Position Management** - New check order/position logic

### Full-Auto Conditions (8 checks)

All must pass:

1. **Signal ≥ 4** (0-10 scale) = STRONG or MEDIUM
2. **SL < 100 points** (stop loss limit)
3. **Risk = 2%** (per trade)
4. **R:R ≥ 1.0** (risk/reward ratio)
5. **Orders < UNLIMITED** (daily cap - currently unlimited)
6. **Loss > -20%** (circuit breaker, daily)
7. **Equity > $0.10** (minimum equity)
8. **Balance > $0.05** (minimum balance)

### Position & Order Management

**STEP 9 (New Position Check):**

When an old order/position exists:

```
IF no old order/position:
  → Can create new trade ✅

IF old order/position exists:
  → Compare trend:
  
  IF trend unchanged AND lotsize <= old lotsize:
    → Keep position, NO action ✅
  
  IF trend unchanged BUT lotsize > old lotsize:
    → Check P&L:
    IF profit >= 2%: Close old + Create new ✅
    ELSE: Wait, no action
  
  IF trend changed:
    → Check P&L:
    IF loss >= 2%: Close old + Create new ✅
    ELSE: Wait, no action
```

### Profit Threshold Rule

When trend changes and position is open:

```
IF profit ≥ 2%:
  → Close old position + Create new order
ELSE IF loss ≥ 2%:
  → Close old position + Create new order
ELSE IF |P&L| < 2%:
  → WAIT and monitor
```

## Advanced Configuration

For detailed system documentation, see:

- **Complete review:** `references/COMPLETE-SYSTEM-REVIEW.md`
- **STEP-by-step guide:** `references/STEP-0-10-GUIDE.md`
- **Full-auto conditions:** `references/PHASE-2-3-CONDITIONS.md`
- **CRON scheduling (38 sec):** `references/CRON-SCHEDULING.md`

## Important Notes

### ✅ DO:

- Use environment variables for credentials (`.env` file)
- Test with small lots (0.001 minimum)
- Monitor trading activity regularly
- Keep account funded
- Review logs for errors
- Check M15 charts for volatility analysis

### ❌ DON'T:

- Hardcode credentials in scripts
- Share your API Key or Account ID
- Commit `.env` to version control
- Use fixed SL/TP values
- Trade multiple positions simultaneously
- Ignore Position Check (STEP 9) conditions

## Architecture

**API-Only Data:**
- All analysis from MetaApi real-time data
- M15 candles from getCandles()
- No external price feeds
- No cached prices
- Fresh data every cycle

**Golden Rules:**
1. One trade at a time (max 1 open position)
2. Fresh entry price every cycle
3. Dynamic SL/TP from M15 volatility
4. 2% risk per trade
5. -20% daily loss circuit breaker
6. Position check BEFORE execution (STEP 9)

## Support & Documentation

Each file contains detailed comments explaining every step. Start with `kanutsanan-pongpanna-trade-check.js` to understand the logic, then `kanutsanan-pongpanna-full-auto.js` for automation.

---

## Usage Instructions

### Quick Setup (5 minutes)

1. **Extract the ZIP file**
   ```bash
   unzip kanutsanan-pongpanna-ai-auto-trading-for-mt5.zip
   cd kanutsanan-pongpanna-ai-auto-trading-for-mt5
   ```

2. **Install dependencies**
   ```bash
   bash scripts/setup.sh
   ```
   Or manually:
   ```bash
   npm install
   ```

3. **Configure credentials**
   ```bash
   nano .env
   ```
   Add your MetaApi credentials:
   - `TOKEN=your-api-key-from-metaapi.cloud`
   - `ACCOUNT_ID=your-account-id-from-metaapi.cloud`

4. **Test trade analysis (manual)**
   ```bash
   source .env
   node scripts/kanutsanan-pongpanna-trade-check-template.js
   ```

5. **Enable automatic trading (optional)**
   ```bash
   bash scripts/cron-setup.sh
   ```
   System will run automatically every 38 seconds

### What You Get

✅ **Real-time trade analysis** (STEP 0-10)
   - Fresh API data every cycle
   - M15 chart volatility analysis
   - Dynamic SL/TP calculation
   - Professional signal scoring (0-10)
   - Smart position management

✅ **Full automation** (PHASE 1-3B)
   - 8 safety conditions
   - Position management with P&L check
   - Execution & verification
   - Every 38 seconds

✅ **CRON scheduling** 
   - Every 38 seconds (2,257 runs/week)
   - Monday-Friday + Sunday/Friday specials
   - Automatic 24/7 trading

✅ **Safety features**
   - One trade at a time
   - -20% daily loss circuit breaker
   - Profit threshold (±2%)
   - Risk management (2% per trade)
   - Position check with trend analysis

### Professional Documentation Included

- **STEP-0-10-GUIDE.md** - Detailed analysis walkthrough
- **PHASE-2-3-CONDITIONS.md** - Execution rules & safety checks
- **CRON-SCHEDULING.md** - Timing (38 sec) & monitoring guide

### Security

✅ NO credentials hardcoded
✅ All sensitive data in .env (git-ignored)
✅ Safe for distribution
✅ Users control their own API keys

---

**Ready to trade?**

1. Set your credentials in `.env`
2. Run: `source .env && node scripts/kanutsanan-pongpanna-trade-check-template.js`
3. Review output and understand the system
4. When confident: `bash scripts/cron-setup.sh` for 24/7 trading every 38 seconds

Created by: **Kanutsanan Pongpanna**
Good luck! 💛
