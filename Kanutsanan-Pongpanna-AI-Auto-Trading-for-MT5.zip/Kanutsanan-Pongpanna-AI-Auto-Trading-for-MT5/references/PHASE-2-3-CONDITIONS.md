# PHASE 2-3: Conditions & Execution (UPDATED)

Full-auto validation and trade execution workflow with every 38 second CRON scheduling.

## PHASE 2: Validate 8 Conditions

**Time:** 1-2 seconds per cycle
**Frequency:** Every 38 seconds
**Purpose:** Verify all requirements before executing trade

### Condition 1: Signal Strength

**Requirement:** STRONG or MEDIUM (score >= 4 on 0-10 scale)

```
Score calculation:
  Base: 4 points
  + 2 if R/R >= 1.5
  + 1 if volatility > 50 points (M15)
  + 1 if volatility > 100 points (M15)
  
Interpretation:
  0-3: WEAK (skip)
  4-5: MEDIUM (execute with caution)
  6-10: STRONG (execute normally)
```

**Action:**
- Score >= 4: ✅ PASS
- Score < 4: ❌ FAIL (wait for better signal)

---

### Condition 2: Stop Loss Points

**Requirement:** SL < 100 points

```
Calculation:
  SL Points = |SL - Entry|
  
Example:
  Entry: 5155.59
  SL: 5178.82
  SL Points: 23.23 ✅
```

**Reasoning:** Large SL means high risk, indicates weak signal

**Action:**
- SL < 100: ✅ PASS
- SL >= 100: ❌ FAIL (recalculate)

---

### Condition 3: Risk Per Trade

**Requirement:** 2% of account balance

```
Calculation:
  Risk Amount = Balance × 2%
  Lot Size = Risk Amount / SL Points
  
Example:
  Balance: $0.28
  Risk (2%): $0.0056
  SL Points: 23.23
  Lot Size: 0.0056 / 23.23 = 0.000241
  → Rounded to: 0.001 lot
```

**Action:**
- Always 2%: ✅ PASS (automatic)

---

### Condition 4: Risk/Reward Ratio

**Requirement:** R/R >= 1.0

```
Calculation:
  Risk = |Entry - SL|
  Reward = |TP - Entry|
  R/R = Reward / Risk
  
Example:
  Risk: 23.23 points
  Reward: 58.09 points
  R/R: 2.5 ✅
```

**Interpretation:**
- R/R >= 1.0: Reward >= Risk ✅
- R/R < 1.0: Reward < Risk ❌

**Action:**
- R/R >= 1.0: ✅ PASS
- R/R < 1.0: ❌ FAIL

---

### Condition 5: Daily Order Count

**Requirement:** UNLIMITED (no cap)

```
Updated 2024-03-07:
  Old: < 100 trades per day
  New: UNLIMITED trades per day
  
Reason: Allow full trading flexibility with 38-second cycles
```

**Action:**
- Always pass: ✅ PASS (automatic)

---

### Condition 6: Daily Loss Limit

**Requirement:** Loss > -20% (circuit breaker)

```
Calculation:
  Daily Loss % = (Current Balance - Starting Balance) / Starting Balance
  Max Daily Loss = Balance × -20%
  
Example:
  Starting Balance: $0.30
  Current Balance: $0.28
  Loss: -$0.02 = -6.7%
  Limit: -$0.06 = -20%
  Status: ✅ PASS (still -6.7% away from limit)
```

**Circuit Breaker:**
- When daily loss >= -20%: BLOCK all new trades
- Resets automatically next UTC day
- Protects capital from large daily losses

**Action:**
- Loss > -20%: ✅ PASS (can trade)
- Loss <= -20%: ❌ FAIL (stop trading)

---

### Condition 7: Equity Health

**Requirement:** Equity > $0.10

```
Equity = Balance + Open Position Profit/Loss

Importance: Prevents margin calls
```

**Action:**
- Equity > $0.10: ✅ PASS
- Equity <= $0.10: ❌ FAIL

---

### Condition 8: Account Balance

**Requirement:** Balance > $0.05

```
Balance = Account money (not including open positions)

Importance: Minimum operating capital
```

**Action:**
- Balance > $0.05: ✅ PASS
- Balance <= $0.05: ❌ FAIL

---

## All 8 Conditions Summary

| # | Condition | Value | Pass |
|---|-----------|-------|------|
| 1 | Signal | STRONG/MEDIUM | >= 4/10 |
| 2 | SL Points | < 100 | ✅ |
| 3 | Risk | 2% | ✅ |
| 4 | R/R Ratio | >= 1.0 | ✅ |
| 5 | Daily Orders | UNLIMITED | ✅ |
| 6 | Daily Loss | > -20% | ✅ |
| 7 | Equity | > $0.10 | ✅ |
| 8 | Balance | > $0.05 | ✅ |

**Decision:**
- ALL 8 PASS: ✅ Execute trade
- ANY 1 FAIL: ❌ Wait/Skip

---

## PHASE 3: Execute Trade

**Time:** 5-10 seconds
**Purpose:** Create order on broker
**Triggered:** Every 38 seconds IF conditions pass

### Step 1: Check Position Status (STEP 9)

Before creating a new order, verify position status:

```javascript
// STEP 9 Logic
IF no position and no order:
  → Can create new ✅
  
IF position exists:
  → Check trend and P&L
  → May need to close old first
  
IF order pending:
  → WAIT, don't create new
```

---

### Step 2: Close Old Position (if needed)

```javascript
if (oldPosition && shouldClose) {
  // Close the old position
  await connection.closePosition(oldPosition.id);
  console.log('Old position closed');
  
  // Now safe to create new
}
```

---

### Step 3: Create Order (PRIMARY)

```javascript
// Always try to create order
if (signalType === 'BUY') {
  order = await connection.createMarketBuyOrder(
    SYMBOL,
    lotSize,
    {
      stopLoss: sl,
      takeProfit: tp,
      comment: `KanutsananPongpanna BUY ${timestamp}`
    }
  );
} else {
  order = await connection.createMarketSellOrder(
    SYMBOL,
    lotSize,
    {
      stopLoss: sl,
      takeProfit: tp,
      comment: `KanutsananPongpanna SELL ${timestamp}`
    }
  );
}
```

**Important:** Order creation is PRIMARY
- Always execute if conditions pass
- Do NOT cancel order if SL/TP fails

---

### Step 4: Set SL/TP (SECONDARY - Optional)

```javascript
// Try to set SL/TP
try {
  await connection.updateOrder(order.orderId, {
    stopLoss: sl,
    takeProfit: tp
  });
  console.log('✅ SL/TP set successfully');
} catch (error) {
  console.warn('⚠️ SL/TP setting failed');
  console.warn('   But order is still OPEN');
  console.warn('   Adjust SL/TP manually on platform');
}
```

**Important:** SL/TP is SECONDARY
- If SL/TP fails, order stays OPEN
- User can adjust manually
- Circuit breaker still protects (-20% daily loss)

---

### Step 5: Fallback Lot Size

```javascript
// If margin error occurs
if (error.message.includes('insufficient') || 
    error.message.includes('margin')) {
  
  console.log('⚠️ Insufficient margin');
  console.log('🔄 Retrying with fallback lot: 0.001');
  
  // Retry with minimum lot
  order = await connection.createMarketBuyOrder(
    SYMBOL,
    0.001,  // Minimum lot
    { stopLoss: sl, takeProfit: tp }
  );
  
  console.log('✅ Order created with fallback lot');
}
```

**Fallback Rule:**
- Primary attempt: Calculated lot
- If margin error: Retry with 0.001 lot
- If still fails: Skip trade and wait

---

### Step 6: Update Daily State

```javascript
// Track today's trades
dailyState.tradeCount++;
dailyState.lastTradeTime = new Date();

// Optional: Track P&L
if (order.type === 'POSITION_TYPE_BUY') {
  // Monitor position
}
```

---

## PHASE 3B: Final Verification

**Time:** 1-2 seconds
**Purpose:** Confirm order was created on broker
**Triggered:** Immediately after execution

### Verification Steps

```javascript
// Get order from broker
const finalVerify = await connection.getOrder(orderId);

if (finalVerify && finalVerify.id) {
  console.log('✅ ORDER VERIFIED ON BROKER');
  console.log(`   Order ID: ${finalVerify.id}`);
  console.log(`   Status: LIVE`);
  console.log(`   Entry: ${finalVerify.openPrice.toFixed(2)}`);
  console.log(`   SL: ${finalVerify.stopLoss ? finalVerify.stopLoss.toFixed(2) : 'NOT SET'}`);
  console.log(`   TP: ${finalVerify.takeProfit ? finalVerify.takeProfit.toFixed(2) : 'NOT SET'}`);
  
  // ✅ SUCCESS
  console.log('\n✅ EXECUTION COMPLETE');
  
} else {
  console.log('❌ ORDER NOT FOUND ON BROKER');
  console.log('   Order may have been rejected');
  console.log('   Status: REJECTED');
  
  // ❌ FAILURE
  console.log('\n❌ EXECUTION FAILED');
}
```

---

## Complete PHASE 2-3 Flow (38 Seconds)

```
Cycle starts every 38 seconds
  ↓
PHASE 1: Trade check (15-20 sec)
  ├─ STEP 0-10 analysis
  │
  └─ Can trade? 
       │
       ├─ No → WAIT (exit cycle)
       │
       └─ Yes → Continue
            ↓
PHASE 2: Validate 8 Conditions (1-2 sec)
  ├─ Condition 1-8 all PASS? ✅
  │  └─ No → WAIT (skip)
  │
  └─ Yes → Continue
       ↓
PHASE 3: Execute Trade (5-10 sec)
  ├─ Check STEP 9 (position status)
  ├─ Close old position if needed
  ├─ Create order ✅
  ├─ Try set SL/TP (optional)
  │
  └─ Order created? 
       │
       ├─ Margin error → Retry with 0.001 lot
       │
       ├─ Yes → Continue
       │
       └─ No → FAIL (wait)
            ↓
PHASE 3B: Final Verification (1-2 sec)
  ├─ Order exists on broker?
  │
  ├─ Yes → ✅ SUCCESS (COMPLETE)
  │
  └─ No → ❌ FAILED (check logs)

End of cycle (waits 38 seconds for next)
```

---

## Decision Tree

```
IF STEP 9 position check fails:
  → Cannot create new
  → Return to wait state

IF conditions not all met:
  → WAIT (return to PHASE 1 next cycle)

IF all conditions pass:
  → Execute order (PRIMARY)
  → Set SL/TP (SECONDARY, optional)
  
  IF order created:
    → Verify on broker (PHASE 3B)
    
    IF verified:
      → SUCCESS ✅
      → Monitor position
    
    ELSE:
      → FAILED ❌
      → Check logs
  
  ELSE:
    IF margin error:
      → Retry with 0.001 lot
    ELSE:
      → FAILED ❌
      → Log error
```

---

## 38-Second Cycle Timing

Each execution cycle (38 seconds):

```
0-20 sec:   PHASE 1 (Trade analysis STEP 0-10)
20-22 sec:  PHASE 2 (Validate 8 conditions)
22-32 sec:  PHASE 3 (Execute + close old position)
32-34 sec:  PHASE 3B (Final verification)
34-38 sec:  Buffer + return
```

**Next cycle:** Immediately after, every 38 seconds

---

## Summary

| Phase | Time | Purpose |
|-------|------|---------|
| 1 | 15-20s | STEP 0-10 analysis + STEP 9 check |
| 2 | 1-2s | Validate 8 conditions |
| 3 | 5-10s | Create order + close old |
| 3B | 1-2s | Verify on broker |

**Total:** 22-34 seconds per cycle
**Frequency:** Every 38 seconds
**Weekly:** 2,257 cycles/week

Ready for high-frequency M15 trading! 🚀
