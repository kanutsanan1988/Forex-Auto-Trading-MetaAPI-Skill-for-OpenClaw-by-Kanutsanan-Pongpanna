# STEP 0-10 Complete Guide (UPDATED)

Trade analysis workflow with detailed explanations of each step - including M15 chart analysis and smart position management.

## 📋 STEP ORDERING (NEW)

The 10 steps have been reordered to improve logic flow:

1. Market status
2. Fresh entry price
3. **M15 Chart analysis** (instead of 24h)
4. Dynamic SL/TP
5. Risk/Reward ratio
6. Position sizing
7. Signal strength
8. SL/TP validation
9. **Position & Order check** (MOVED TO END)
10. Trade recommendation

---

## STEP 0: Market Status Check

**Purpose:** Verify market is open and API is responsive

**API Call:** `getSymbolPrice(SYMBOL)`

**What it does:**
- Fetches current bid/ask prices from broker
- Confirms market is trading
- Gets real-time data

**Example output:**
```
Bid: 5155.23
Ask: 5155.95
```

---

## STEP 1: Fresh Entry Price

**Purpose:** Get the exact entry price to use for calculations

**Calculation:** `(bid + ask) / 2` = mid-price

**Important:**
- Fresh every cycle (not cached)
- Real-time from API
- Mid-point between bid/ask

**Example:**
```
Bid: 5155.23
Ask: 5155.95
Entry: 5155.59
```

---

## STEP 2: Chart Analysis (M15 CANDLES)

**Purpose:** Analyze M15 candles to understand volatility and trend

**API Call:** `getCandles(SYMBOL, '15m', {limit: 100})`

**What it calculates:**
- Support (lowest in M15 candles)
- Resistance (highest in M15 candles)
- Volatility = Resistance - Support
- Trend = which side of midpoint

**Important Changes:**
- ✅ Uses **M15 candles** (not 24h deal history)
- ✅ Analyzes up to 100 bars
- ✅ Gets high/low from candle data

**Example:**
```
M15 Candles: 100 bars analyzed
Support: 5039.78
Resistance: 5155.95
Volatility: 116.17 points
Trend: UP (entry above midpoint)
```

---

## STEP 3: Dynamic SL & TP Calculation

**Purpose:** Set stop loss and take profit dynamically based on volatility

**Formulas:**
```
SL Buffer = Volatility × 0.20 (20%)
TP Buffer = Volatility × 0.50 (50%)
```

**For SELL signal (Trend DOWN):**
```
SL = Entry + SL Buffer (above)
TP = Entry - TP Buffer (below)
```

**For BUY signal (Trend UP):**
```
SL = Entry - SL Buffer (below)
TP = Entry + TP Buffer (above)
```

**Example (SELL):**
```
Entry: 5155.59
Volatility: 116.17
SL Buffer: 23.23 points
TP Buffer: 58.09 points

SL = 5155.59 + 23.23 = 5178.82
TP = 5155.59 - 58.09 = 5097.50
```

---

## STEP 4: Risk/Reward Ratio

**Purpose:** Ensure trade has good reward relative to risk

**Calculation:**
```
Risk = |Entry - SL|
Reward = |TP - Entry|
R/R Ratio = Reward / Risk

Requirement: R/R >= 1.0
```

**Example:**
```
Entry: 5155.59
SL: 5178.82
TP: 5097.50

Risk: 23.23 points
Reward: 58.09 points
R/R: 2.5 ✅
```

---

## STEP 5: Position Sizing (2% Risk Rule)

**Purpose:** Calculate correct lot size for 2% risk per trade

**Calculation:**
```
Risk Amount = Balance × 2%
Lot Size = Risk Amount / SL Points

Round DOWN to valid broker lot size
Minimum: 0.001 lot
```

**Example:**
```
Balance: $0.28
Risk: 2%
Risk Amount: $0.0056

SL Points: 23.23
Calculated Lot: 0.0056 / 23.23 = 0.000241

Rounded DOWN to: 0.001 lot (minimum)
```

---

## STEP 6: Signal Strength (0-10 Scale)

**Purpose:** Score the quality of the trade signal

**Scoring:**
```
Base: 4 points
+ 2 if R/R >= 1.5
+ 1 if volatility > 50
+ 1 if volatility > 100

Total: 0-10 points (capped at 10)
```

**Interpretation:**
```
0-3: WEAK (skip trade)
4-5: MEDIUM (trade with caution)
6-10: STRONG (good to trade)
```

**Example:**
```
Base: 4
R/R 2.5 >= 1.5: +2
Volatility 116 > 50: +1
Volatility 116 > 100: +1

Total: 8/10 = STRONG ✅
```

---

## STEP 7: Validate SL/TP Direction

**Purpose:** Ensure stop loss and take profit are on correct sides

**For BUY:**
```
Requirement: SL < Entry < TP
Example:
  SL: 5155.00
  Entry: 5155.59
  TP: 5156.00
  ✅ Valid
```

**For SELL:**
```
Requirement: TP < Entry < SL
Example:
  TP: 5154.00
  Entry: 5155.59
  SL: 5156.00
  ✅ Valid
```

---

## STEP 8: Final API Verification

**Purpose:** Confirm all data came from API, no external sources

**Checks:**
- Entry price: from getSymbolPrice() ✓
- M15 Volatility: from getCandles() ✓
- Account info: from getAccountInformation() ✓
- NO external data sources ✓

---

## STEP 9: Position & Order Check (MOVED TO END)

**Purpose:** Smart management of existing orders/positions with profit threshold logic

**CASE 1: Ready (0 positions, 0 orders)**
```
Status: CLEAR ✅
Action: Can create new trade
```

**CASE 2: Position Open, Same Trend**
```
Old Trend = New Trend

2a) If lotsize ≤ old:
    Action: NO ACTION ✅
    Reason: Keep existing position

2b) If lotsize > old AND profit ≥ 2%:
    Action: CLOSE OLD + CREATE NEW ✅
    Reason: Profit threshold reached

2c) If lotsize > old AND profit < 2%:
    Action: WAIT ⏸️
    Reason: Insufficient profit yet
```

**CASE 3: Position Open, Trend Changed**
```
Old Trend ≠ New Trend

3a) If profit ≥ 2%:
    Action: CLOSE OLD + CREATE NEW ✅
    Reason: Trend reversed with profit

3b) If loss ≥ 2%:
    Action: CLOSE OLD + CREATE NEW ✅
    Reason: Trend reversed with loss at threshold

3c) If -2% < P&L < 2%:
    Action: WAIT ⏸️
    Reason: P&L not at threshold yet
```

**CASE 4: Pending Order (0 positions, 1+ orders)**
```
Status: PENDING ⏸️
Action: WAIT for execution
Reason: Cannot create multiple pending orders
```

**CASE 5: Multiple (> 1 of anything)**
```
Status: ERROR ❌
Action: STOP - Manual review needed
Reason: System violation
```

---

## STEP 10: Trade Recommendation

**Purpose:** Summarize the complete analysis and recommend action

**Output:**
```
Signal: SELL (STRONG)
Entry: 5155.59
SL: 5178.82 (23.23 points)
TP: 5097.50 (58.09 points)
Lot: 0.001
R/R: 2.5 : 1
Status: READY ✅
Action: CAN_CREATE_NEW
```

**Decision Matrix:**

| Position Status | Can Create | Action |
|-----------------|-----------|--------|
| CLEAR | ✅ Yes | Create new |
| SAME_TREND_NO_CHANGE | ❌ No | Wait |
| CLOSE_PROFIT_THRESHOLD | ✅ Yes | Close old + create |
| WAIT_PROFIT | ❌ No | Wait |
| CLOSE_TREND_CHANGE | ✅ Yes | Close old + create |
| WAIT_THRESHOLD | ❌ No | Wait |
| PENDING_ORDER | ❌ No | Wait |
| ERROR_ABNORMAL | ❌ No | Stop |

---

## Complete Example Trade

```
STEP 0: Market open ✓
STEP 1: Entry = 5155.59
STEP 2: M15 Volatility = 116.17, Trend = DOWN
STEP 3: SL = 5178.82, TP = 5097.50
STEP 4: R/R = 2.5 ✓
STEP 5: Lot = 0.001
STEP 6: Score = 8/10 = STRONG
STEP 7: SELL direction valid ✓
STEP 8: API verified ✓
STEP 9: No position - CLEAR ✓
STEP 10: SELL STRONG - READY ✅

→ Can create new trade!
```

---

## M15 Analysis Benefits

### Why M15 Instead of 24h?

- ✅ **More Responsive:** Captures current market conditions
- ✅ **Better Volatility:** Real-time support/resistance
- ✅ **Filtered Noise:** Medium timeframe balances detail and trends
- ✅ **Professional:** Traders use M15 for entry precision
- ✅ **100 Bars:** Provides 1,500 minutes (25 hours) of history

### M15 Candle Data

```javascript
candles = await connection.getCandles(SYMBOL, '15m', {limit: 100});

Each candle has:
- open: Opening price
- high: Highest in period
- low: Lowest in period
- close: Closing price
- time: Candle timestamp
```

---

## Summary

| Step | What | Why | Updated |
|------|------|-----|---------|
| 0 | Market check | Verify trading | No |
| 1 | Fresh entry | Real-time | No |
| 2 | **M15 analysis** | **Volatility** | ✅ YES |
| 3 | Dynamic SL/TP | Proportional | No |
| 4 | R/R ratio | Risk control | No |
| 5 | Position sizing | 2% rule | No |
| 6 | Signal strength | Quality score | No |
| 7 | Validate S/TP | Direction check | No |
| 8 | API verify | Data integrity | No |
| 9 | **Position check** | **Smart mgmt** | ✅ YES (Moved) |
| 10 | Recommendation | Final decision | Updated |

**Key Changes:**
1. Chart analysis uses **M15 getCandles()** instead of deal history
2. Position check moved to **STEP 9** (end)
3. Smart position management with **profit thresholds**
4. New logic for **trend-change handling**
