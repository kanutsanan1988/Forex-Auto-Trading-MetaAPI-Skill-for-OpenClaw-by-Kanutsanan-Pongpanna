#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# KANUTSANAN-PONGPANNA AUTO-TRADING - SETUP SCRIPT
# ═══════════════════════════════════════════════════════════════

set -e

echo "════════════════════════════════════════════════════════════"
echo "🚀 KANUTSANAN-PONGPANNA AUTO-TRADING SETUP"
echo "════════════════════════════════════════════════════════════"
echo ""

# Step 1: Install Node.js dependencies
echo "📦 Step 1: Installing Node.js dependencies..."
npm install
echo "✅ Dependencies installed"
echo ""

# Step 2: Create environment file
echo "🔐 Step 2: Setting up environment..."
if [ ! -f .env ]; then
  cp assets/config-template.env .env
  echo "✅ Created .env file"
  echo "   ⚠️  IMPORTANT: Edit .env with your MetaApi credentials"
else
  echo "✅ .env file already exists"
fi
echo ""

# Step 3: Create logs directory
echo "📁 Step 3: Creating logs directory..."
mkdir -p logs
echo "✅ Logs directory created"
echo ""

# Step 4: Make scripts executable
echo "🔧 Step 4: Making scripts executable..."
chmod +x scripts/*.sh
echo "✅ Scripts are executable"
echo ""

echo "════════════════════════════════════════════════════════════"
echo "✅ SETUP COMPLETE!"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "📋 Next Steps:"
echo ""
echo "1️⃣  Edit your credentials:"
echo "   nano .env"
echo "   (Add your TOKEN and ACCOUNT_ID)"
echo ""
echo "2️⃣  Test trade analysis:"
echo "   source .env"
echo "   node scripts/kanutsanan-pongpanna-trade-check-template.js"
echo ""
echo "3️⃣  Enable automatic trading:"
echo "   bash scripts/cron-setup.sh"
echo ""
echo "4️⃣  Monitor logs:"
echo "   tail -f logs/kanutsanan-pongpanna-main.log"
echo ""
echo "Happy trading! 💛"
echo ""
