#!/usr/bin/env node

/**
 * KANUTSANAN-PONGPANNA TRADE CHECK - Template Version
 * 
 * ⚠️ SETUP REQUIRED:
 * 1. Set environment variables: TOKEN and ACCOUNT_ID
 * 2. Run: source .env && node kanutsanan-pongpanna-trade-check-template.js
 * 
 * 🔐 SECURITY:
 * - Do NOT hardcode credentials
 * - Use environment variables ONLY
 * - Never commit .env to git
 * 
 * 📋 STEPS (REORDERED):
 * STEP 0: Market Status Check
 * STEP 1: Fresh Entry Price (Real-time)
 * STEP 2: Chart Analysis (M15 Candles)
 * STEP 3: Dynamic SL/TP Calculation
 * STEP 4: Risk/Reward Ratio (≥1.0)
 * STEP 5: Position Sizing (2% Rule)
 * STEP 6: Signal Strength (0-10)
 * STEP 7: Validate SL/TP Direction
 * STEP 8: Final API Verification
 * STEP 9: Position & Order Check (MOVED TO END)
 * STEP 10: Trade Recommendation
 */

let MetaApi = require('metaapi.cloud-sdk').default;

// 🔴 GET CREDENTIALS FROM ENVIRONMENT (NOT HARDCODED)
let token = process.env.TOKEN;
let accountId = process.env.ACCOUNT_ID;

// 🔴 VALIDATE CREDENTIALS
if (!token || !accountId) {
  console.error('\n❌ ERROR: Missing required environment variables!\n');
  console.error('Setup Instructions:');
  console.error('  1. Edit .env file with your credentials');
  console.error('  2. Run: source .env');
  console.error('  3. Run: node kanutsanan-pongpanna-trade-check-template.js\n');
  console.error('Example .env:');
  console.error('  export TOKEN="your-metaapi-key-here"');
  console.error('  export ACCOUNT_ID="your-account-id-here"\n');
  process.exit(1);
}

const SYMBOL = 'XAUUSD.sml';
const api = new MetaApi(token);

async function selectLotSize(calculatedSize) {
  const LOT_OPTIONS = [0.001, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.10, 
                       0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.00,
                       2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.00, 10.00];
  
  if (calculatedSize < 0.001) return 0.001;
  
  let closestLower = null;
  for (let i = LOT_OPTIONS.length - 1; i >= 0; i--) {
    if (LOT_OPTIONS[i] <= calculatedSize) {
      closestLower = LOT_OPTIONS[i];
      break;
    }
  }
  
  return closestLower || 0.001;
}

async function checkTrade() {
  try {
    console.log('\n═══════════════════════════════════════════');
    console.log('🤖 KANUTSANAN-PONGPANNA TRADE CHECK');
    console.log('═══════════════════════════════════════════\n');

    const account = await api.metatraderAccountApi.getAccount(accountId);
    const initialState = account.state;
    const deployedStates = ['DEPLOYING', 'DEPLOYED'];

    if(!deployedStates.includes(initialState)) {
      console.log('📊 กำลังดำเนินการ Deployment...');
      await account.deploy();
    }
  
    console.log('⏳ รอให้ API เชื่อมต่อ...');
    await account.waitConnected();

    let connection = account.getRPCConnection();
    await connection.connect();

    console.log('⏳ รอให้ SDK ซิงโครไนซ์...');
    await connection.waitSynchronized();

    // ✅ STEP 0: Market Status
    console.log('\n🔴 STEP 0: ตรวจสอบตลาดเปิด');
    const symbolPrice = await connection.getSymbolPrice(SYMBOL);
    console.log(`  Bid: ${symbolPrice.bid}, Ask: ${symbolPrice.ask}`);

    // ✅ STEP 1: Fresh Entry Price (Real-time)
    console.log('\n🔴 STEP 1: ดึงราคา Entry ที่ REAL-TIME');
    const entry = (symbolPrice.bid + symbolPrice.ask) / 2;
    console.log(`  Entry Price: ${entry}`);

    // ✅ STEP 2: Chart Analysis (M15 Candles)
    console.log('\n🔴 STEP 2: วิเคราะห์กราฟ M15 (getCandles)');
    let candles = [];
    try {
      // ดึง M15 candles (100 bar เพื่อได้ข้อมูลหลายชั่วโมง)
      candles = await connection.getCandles(SYMBOL, '15m', {limit: 100});
    } catch (e) {
      console.log(`  (No M15 candle history available)`);
    }
    
    let prices = [symbolPrice.bid, symbolPrice.ask, entry];
    if (candles && candles.length > 0) {
      // เอา high/low จาก M15 candles
      prices = prices.concat(candles.map(c => c.high || c.open));
      prices = prices.concat(candles.map(c => c.low || c.open));
    }
    
    const highestPrice = Math.max(...prices);
    const lowestPrice = Math.min(...prices);
    const resistance = highestPrice;
    const support = lowestPrice;
    const volatility = Math.max(resistance - support, 20);
    
    console.log(`  Support (M15): ${support.toFixed(2)}, Resistance (M15): ${resistance.toFixed(2)}`);
    console.log(`  Volatility (M15): ${volatility.toFixed(2)} points`);
    console.log(`  Candles analyzed: ${candles.length}`);
    
    const trend = entry > (support + resistance) / 2 ? 'UP' : 'DOWN';
    console.log(`  Trend: ${trend}`);

    // ✅ STEP 3: Dynamic SL/TP
    console.log('\n🔴 STEP 3: คำนวณ SL & TP (DYNAMIC)');
    const effectiveVolatility = volatility > 0 ? volatility : 20;
    const slBuffer = effectiveVolatility * 0.20;
    const tpBuffer = effectiveVolatility * 0.50;
    
    let sl, tp, signalType;
    if (trend === 'DOWN') {
      sl = entry + slBuffer;
      tp = entry - tpBuffer;
      signalType = 'SELL';
    } else {
      sl = entry - slBuffer;
      tp = entry + tpBuffer;
      signalType = 'BUY';
    }
    
    const slPoints = Math.abs(sl - entry);
    const tpPoints = Math.abs(tp - entry);
    
    console.log(`  Signal: ${signalType}`);
    console.log(`  SL: ${sl.toFixed(2)} (${slPoints.toFixed(2)} points)`);
    console.log(`  TP: ${tp.toFixed(2)} (${tpPoints.toFixed(2)} points)`);

    // ✅ STEP 4: Risk/Reward (ย้ายมาก่อน Position Sizing)
    console.log('\n🔴 STEP 4: Risk/Reward Ratio');
    const risk = Math.abs(entry - sl);
    const reward = Math.abs(tp - entry);
    const ratio = reward / risk;
    console.log(`  Risk: ${risk.toFixed(2)} points`);
    console.log(`  Reward: ${reward.toFixed(2)} points`);
    console.log(`  R/R Ratio: ${ratio.toFixed(2)} : 1`);
    
    if (ratio < 1.0) {
      console.log('  ⚠️ R/R ratio < 1.0 - Signal too weak');
      // ไม่ return ตัวอักษร STEP เพื่อให้ดำเนินการต่อไป
    }

    // ✅ STEP 5: Position Sizing
    console.log('\n🔴 STEP 5: Position Sizing (2% Risk)');
    const accountInfo = await connection.getAccountInformation();
    const balance = accountInfo.balance;
    const riskAmount = balance * 0.02;
    const calculatedSize = riskAmount / slPoints;
    const selectedLot = await selectLotSize(calculatedSize);
    
    console.log(`  Balance: $${balance.toFixed(4)}`);
    console.log(`  Risk (2%): $${riskAmount.toFixed(4)}`);
    console.log(`  SL Points: ${slPoints.toFixed(2)}`);
    console.log(`  Calculated Lot: ${calculatedSize.toFixed(6)}`);
    console.log(`  Selected Lot: ${selectedLot}`);

    // ✅ STEP 6: Signal Strength
    console.log('\n🔴 STEP 6: Signal Strength (0-10 Score)');
    let score = 4; // Base score
    if (ratio >= 1.5) score += 2;
    if (volatility > 50) score += 1;
    if (volatility > 100) score += 1;
    
    // Cap at 10
    score = Math.min(score, 10);
    
    let strength = 'WEAK';
    if (score >= 6) strength = 'STRONG';
    else if (score >= 4) strength = 'MEDIUM';
    
    console.log(`  Base: 4 points`);
    if (ratio >= 1.5) console.log(`  + 2 (R/R >= 1.5)`);
    if (volatility > 50) console.log(`  + 1 (Volatility > 50)`);
    if (volatility > 100) console.log(`  + 1 (Volatility > 100)`);
    console.log(`  Total Score: ${score}/10 = ${strength}`);

    // ✅ STEP 7: Validate SL/TP
    console.log('\n🔴 STEP 7: ตรวจสอบ SL/TP Direction');
    let slValid = false;
    if (signalType === 'BUY' && sl < entry && tp > entry) {
      slValid = true;
      console.log('  ✅ BUY: SL < Entry < TP');
    } else if (signalType === 'SELL' && sl > entry && tp < entry) {
      slValid = true;
      console.log('  ✅ SELL: TP < Entry < SL');
    }
    
    if (!slValid) {
      console.log('  ❌ SL/TP direction invalid');
      process.exit(1);
    }

    // ✅ STEP 8: Final API Verification
    console.log('\n🔴 STEP 8: Final API Verification');
    console.log('  ✅ Entry price: from getSymbolPrice()');
    console.log('  ✅ Volatility: from getCandles() M15');
    console.log('  ✅ Account info: from getAccountInformation()');
    console.log('  ✅ All data from MetaApi (no external sources)');

    // ✅ STEP 9: Position & Order Check (MOVED TO END)
    console.log('\n🔴 STEP 9: Position & Order Check');
    const positions = await connection.getPositions();
    const orders = await connection.getOrders();
    
    console.log(`  Open Positions: ${positions.length}`);
    console.log(`  Pending Orders: ${orders.length}`);
    
    let canCreateNew = true;
    let actionNote = '';
    
    if (positions.length === 0 && orders.length === 0) {
      console.log('  ✅ Ready - No positions/orders');
      actionNote = 'CAN_CREATE_NEW';
    } else if (positions.length > 0 && orders.length === 0) {
      // มี position เก่า
      const oldPosition = positions[0];
      const oldTrend = oldPosition.type === 'POSITION_TYPE_BUY' ? 'UP' : 'DOWN';
      console.log(`  ⚠️  Old Position Found`);
      console.log(`      Type: ${oldPosition.type}`);
      console.log(`      Trend: ${oldTrend} → New Trend: ${trend}`);
      
      // Check lot size
      const oldLotsize = oldPosition.volume;
      console.log(`      Old Lotsize: ${oldLotsize}, New Lotsize: ${selectedLot}`);
      
      if (oldTrend === trend) {
        // Trend เหมือนเดิม
        if (selectedLot <= oldLotsize) {
          console.log(`  ✅ Same trend, lotsize ≤ old → NO ACTION`);
          actionNote = 'NO_ACTION_SAME_TREND';
          canCreateNew = false;
        } else {
          // Lotsize สูงกว่า - เช็ค profit
          console.log(`  ℹ️  Same trend, lotsize > old → Check profit`);
          const currentProfit = oldPosition.profit || 0;
          const profitPercent = (currentProfit / balance) * 100;
          console.log(`      Current P&L: $${currentProfit.toFixed(4)} (${profitPercent.toFixed(2)}%)`);
          
          if (profitPercent >= 2.0) {
            console.log(`  ✅ Profit ≥ 2% → CLOSE & CREATE NEW`);
            actionNote = 'CLOSE_OLD_PROFIT_THRESHOLD';
            canCreateNew = true;
          } else {
            console.log(`  ⏸️  Profit < 2% → WAIT`);
            actionNote = 'WAIT_PROFIT_THRESHOLD';
            canCreateNew = false;
          }
        }
      } else {
        // Trend เปลี่ยน
        console.log(`  ℹ️  Trend changed → Check loss`);
        const currentProfit = oldPosition.profit || 0;
        const profitPercent = (currentProfit / balance) * 100;
        console.log(`      Current P&L: $${currentProfit.toFixed(4)} (${profitPercent.toFixed(2)}%)`);
        
        if (profitPercent >= 2.0) {
          console.log(`  ✅ Profit ≥ 2% → CLOSE & CREATE NEW`);
          actionNote = 'CLOSE_OLD_TREND_CHANGE_PROFIT';
          canCreateNew = true;
        } else if (profitPercent <= -2.0) {
          console.log(`  ✅ Loss ≥ 2% → CLOSE & CREATE NEW`);
          actionNote = 'CLOSE_OLD_TREND_CHANGE_LOSS';
          canCreateNew = true;
        } else {
          console.log(`  ⏸️  P&L between -2% and +2% → WAIT`);
          actionNote = 'WAIT_THRESHOLD';
          canCreateNew = false;
        }
      }
    } else if (positions.length === 0 && orders.length > 0) {
      console.log('  ⏸️  Pending order open → WAIT');
      actionNote = 'WAIT_PENDING_ORDER';
      canCreateNew = false;
    } else {
      console.log('  ❌ Multiple positions/orders (abnormal)');
      actionNote = 'ERROR_ABNORMAL_STATE';
      canCreateNew = false;
    }

    // ✅ STEP 10: Trade Recommendation
    console.log('\n🔴 STEP 10: Trade Recommendation');
    console.log('\n' + '═'.repeat(50));
    
    if (!canCreateNew) {
      console.log(`⏸️  CANNOT CREATE NEW TRADE`);
      console.log(`   Reason: ${actionNote}`);
      console.log(`   Action: WAIT for next cycle`);
    } else {
      console.log(`✅ TRADE READY: ${strength} ${signalType}`);
      console.log(`   Entry: ${entry.toFixed(2)}`);
      console.log(`   SL: ${sl.toFixed(2)} (${slPoints.toFixed(2)} pts)`);
      console.log(`   TP: ${tp.toFixed(2)} (${tpPoints.toFixed(2)} pts)`);
      console.log(`   Lot: ${selectedLot}`);
      console.log(`   R/R: ${ratio.toFixed(2)} : 1`);
      console.log(`   Signal: ${score}/10 (${strength})`);
      console.log(`   Action: ${actionNote}`);
    }
    
    console.log('═'.repeat(50) + '\n');

    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

checkTrade();
