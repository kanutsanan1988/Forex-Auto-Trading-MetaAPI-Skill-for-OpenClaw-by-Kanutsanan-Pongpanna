#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# KANUTSANAN-PONGPANNA AUTO-TRADING - CRON SETUP
# ═══════════════════════════════════════════════════════════════
# 
# This script sets up CRON jobs to run trading every 38 seconds
# 
# SCHEDULE:
# - Sunday 23:00-23:59 UTC (60 runs)
# - Mon-Fri 00:00-21:59 UTC (every 38 sec) 
# - Friday 22:00 UTC (1 run)
# 
# Total: 2,257 runs per week

set -e

echo "🔄 Setting up Kanutsanan-Pongpanna Auto-Trading CRON..."
echo ""

# Validate environment
if [ -z "$TOKEN" ] || [ -z "$ACCOUNT_ID" ]; then
  echo "❌ ERROR: Missing TOKEN or ACCOUNT_ID"
  echo "   Run: source .env"
  exit 1
fi

echo "✅ Environment variables loaded"
echo ""

# Get current directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
LOG_DIR="$PROJECT_DIR/logs"

# Create log directory
mkdir -p "$LOG_DIR"
echo "📁 Created logs directory: $LOG_DIR"
echo ""

# Remove old CRON jobs (if any)
echo "🗑️  Removing old CRON jobs..."
(crontab -l 2>/dev/null | grep -v "KanutsananPongpanna" || echo "") | crontab - 2>/dev/null || true

echo ""
echo "📋 Installing new CRON jobs..."
echo ""

# Create CRON jobs
CRON_JOBS=$(cat <<EOF
# ═══════════════════════════════════════════════════════════════
# Kanutsanan-Pongpanna Auto-Trading System
# ═══════════════════════════════════════════════════════════════
# Do not edit manually - re-run cron-setup.sh to update

# Job 1: Sunday evening (23:00-23:59 UTC)
# Runs 60 times in that hour
* 23 * * 0 cd $PROJECT_DIR && source .env && node scripts/kanutsanan-pongpanna-full-auto-template.js >> $LOG_DIR/kanutsanan-pongpanna-sunday.log 2>&1

# Job 2: Mon-Fri main trading (00:00-21:59 UTC)
# Runs every 38 seconds during these hours
*/38 0-21 * * 1-5 cd $PROJECT_DIR && source .env && node scripts/kanutsanan-pongpanna-full-auto-template.js >> $LOG_DIR/kanutsanan-pongpanna-main.log 2>&1

# Job 3: Friday evening close (22:00 UTC)
# Runs once per week
0 22 * * 5 cd $PROJECT_DIR && source .env && node scripts/kanutsanan-pongpanna-full-auto-template.js >> $LOG_DIR/kanutsanan-pongpanna-friday.log 2>&1
EOF
)

# Install CRON jobs
echo "$CRON_JOBS" | crontab -

echo "✅ CRON jobs installed successfully!"
echo ""

# Verify installation
echo "📋 Verifying CRON installation..."
echo ""
crontab -l | grep -A 20 "Kanutsanan-Pongpanna"

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ SETUP COMPLETE"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "📊 Scheduling Details:"
echo "   - Frequency: Every 38 seconds"
echo "   - Total runs per week: 2,257"
echo "   - Log files: $LOG_DIR/"
echo ""
echo "🔍 Monitor logs:"
echo "   tail -f $LOG_DIR/kanutsanan-pongpanna-main.log"
echo ""
echo "❌ To disable CRON:"
echo "   crontab -r"
echo ""
echo "🔄 To update CRON:"
echo "   bash scripts/cron-setup.sh"
echo ""
